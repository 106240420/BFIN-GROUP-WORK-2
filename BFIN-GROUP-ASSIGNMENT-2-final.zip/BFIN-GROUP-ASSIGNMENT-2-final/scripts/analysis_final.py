#!/usr/bin/env python
# coding: utf-8

# # Kappa Foundation - Investment Policy Analysis (final submission, 29 October 2026)
# 
# ## Purpose and decision context
# 
# This notebook is our team's final investment-policy analysis for Kappa Foundation. The case starts with USD 12 million on 31 December 2022, fixed nominal payments, and a longer-term goal of preserving the purchasing power of USD 8 million at 31 December 2030.
# 
# Sections 1-8 are the 22 October analysis, kept cell for cell. They rebuild the frozen original policy from the saved raw data, and the final checks stop if the bond units or growth weights differ from `outputs/original/frozen_policy.json`. Sections 9-12 are new. They apply the trustees' revised payment schedule from 23 October (USD 2.4m in 2024, USD 1.2m in 2025, USD 2.4m in 2027) at the same decision date, with the same bond quotes, information cutoff and methods. They also add diagnostics that test our recommendation: an immunization alternative, several ways of measuring the 15% loss concern, a utility comparison with a reversal threshold for risk aversion, and a risk-adjusted 2023-2025 comparison.
# 
# Run the notebook from top to bottom after installing `requirements-lock.txt`. The saved data let it run offline. It writes to `outputs/final_2026-10-29/`. `outputs/original/` stays as the frozen 22 October baseline and the notebook never writes there.
# 
# Inflation, ERP, risk aversion, the reading of the 15% loss concern, the security cap, cash carry and trading costs were chosen by the team on 22 October and are unchanged here. The case does not prescribe them. Table `T37_change_attribution.csv` separates changes caused by the revised mandate from changes to methods or reporting.

# ## Project setup and policy assumptions
# 
# This cell loads the project data and analysis libraries, finds the project root, and sets the input and output paths. It also defines the policy assumptions and the helpers used to save tables and figures.
# 
# Keeping the assumptions together makes it easier to see which values drive the results. Our base case uses 2.5% inflation, a 5% ERP, risk aversion of 4, a 25% maximum weight per security, and 10 bp one-way trading costs. We interpret the stated 15% loss concern as a one-year 95% loss on the total fund. These are team choices, not values prescribed by the case, and the loss measure is not an approved hard limit.
# 
# The only change from the 22 October cell is the output tag `final_2026-10-29`. All policy assumptions are unchanged.

# In[1]:


import json
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy.optimize import brentq, minimize, linprog
from scipy.stats import norm
from IPython.display import display

cwd = Path.cwd()
ROOT = next(
    (candidate for base in (cwd, *cwd.parents) for candidate in (base, base / "kappa")
     if (candidate / "config.json").is_file() and (candidate / "data" / "raw").is_dir()),
    None,
)
if ROOT is None:
    raise FileNotFoundError("Could not find config.json and data/raw from the notebook working directory")
RAW = ROOT / "data" / "raw"
with (ROOT / "config.json").open(encoding="utf-8") as f:
    cfg = json.load(f)
STOCKS, ETFS = cfg["stocks"], cfg["etfs"]; ASSETS = STOCKS + ETFS

# ---------------- ALL ASSUMPTIONS (frozen on 22 Oct; unchanged in the final run) ----------------
P = dict(
    TAG="final_2026-10-29",
    FUND=12_000_000, PAY={2: 2_400_000, 5: 3_600_000},      # year -> USD (2024, 2027)
    GOAL_REAL=8_000_000, GOAL_YEARS=8,                       # Dec-2022 purchasing power, at 31 Dec 2030
    INFLATION=0.025,                                         # base CPI assumption (scenarios 2-4% below)
    ERP=0.05,                                                # forward-looking US equity risk premium
    RISK_AVERSION=4,                                         # A in U = mu - 0.5*A*var
    LOSS_LIMIT=0.15,                                         # 1-yr 95% loss diagnostic threshold, as % of TOTAL fund (our interpretation)
    CASH_BUFFER=250_000,                                     # liquidity / trading-cost reserve, earns 0%
    MAX_W=0.25,                                              # per-security cap in growth sleeve
    TC=0.001,                                                # 10 bp one-way on stocks/ETFs
    WIN=("2015-01", "2022-12"),                              # estimation window (96 months)
    EVAL=("2023-01", "2025-12"),                             # evaluation window, never used for decisions
    BENCH="SPY", FACTOR_STOCKS=["AAPL", "XOM"],
)
OUT = ROOT/"outputs"/P["TAG"]; OUT.mkdir(parents=True, exist_ok=True)
def save_table(df, name):
    df.to_csv(OUT/f"{name}.csv"); display(df.round(4)); return df
def save_fig(name):
    plt.tight_layout(); plt.savefig(OUT/f"{name}.png", dpi=150); plt.show()


# Setup does not create output files. The remaining cells use the paths and assumptions defined here.

# ## 1. Data and return construction
# 
# Total returns use month-end `Adj Close` from the saved daily Yahoo files, which reflects reinvested dividends. We show price-only returns based on `Close` separately. The factor data are the monthly Kenneth French five-factor file; source percentages are converted to decimals, and `-99.99` is treated as missing. FF3 uses Mkt-RF, SMB, and HML; FF5 also includes RMW and CMA. Returns are aligned with factors for the same month.

# ## Market data, factor data, and sample checks
# 
# We read the saved Yahoo CSVs, check their dates and closing prices, and calculate month-end total and price-only returns. We then read the monthly observations in the saved Kenneth French ZIP file, convert factor percentages to decimals, and handle the source's missing-value marker.
# 
# The estimation window is fixed at January 2015 through December 2022 (96 months); 2023-2025 is kept separate for evaluation. The cell checks that dates and factor observations line up and stops if required estimation data are missing or non-finite. It writes the sample summary to `T01_data_quality.csv`.
# 
# These checks help prevent misaligned data or accidental use of percentages as decimal returns. The files are already saved locally, so this cell runs offline. Price history does not establish whether a security was eligible on the case date.

# In[2]:


import zipfile

def load_px(t):
    d = pd.read_csv(RAW/"yahoo"/f"{t}.csv", index_col=0)
    d.index = pd.to_datetime(d.index, utc=True).tz_convert(None).normalize()
    if d.index.has_duplicates or not d.index.is_monotonic_increasing:
        raise ValueError(f"{t}: daily prices contain duplicate or unsorted dates")
    required = ["Adj Close", "Close"]
    if not set(required).issubset(d.columns) or d[required].isna().any().any():
        raise ValueError(f"{t}: missing required adjusted/close prices")
    return d

raw = {t: load_px(t) for t in ASSETS}
def month_end(px): return px.groupby(px.index.to_period("M")).last()
ret_tr = month_end(pd.DataFrame({t: raw[t]["Adj Close"] for t in ASSETS})).pct_change().iloc[1:]
ret_pr = month_end(pd.DataFrame({t: raw[t]["Close"] for t in ASSETS})).pct_change().iloc[1:]

if ret_tr.index.has_duplicates or not ret_tr.index.is_monotonic_increasing:
    raise ValueError("Monthly return index contains duplicate or unsorted months")
if not np.isfinite(ret_tr.to_numpy()).all() or (ret_tr.abs() >= 1).any().any():
    raise ValueError("Monthly total returns must be finite decimal returns, not percentages")

def read_french(zipname, names):
    with zipfile.ZipFile(RAW/"french"/zipname) as z:
        csv_names = [name for name in z.namelist() if name.lower().endswith(".csv")]
        if len(csv_names) != 1:
            raise ValueError(f"{zipname}: expected one CSV member, found {csv_names}")
        lines = z.read(csv_names[0]).decode("latin-1").splitlines()
    rows, started = [], False
    for line in lines:
        p = [x.strip() for x in line.split(",")]
        if len(p[0]) == 6 and p[0].isdigit():
            started = True
            rows.append(p[:len(names)+1])
        elif started:
            break
    if not rows:
        raise ValueError(f"{zipname}: no monthly observations found")
    df = pd.DataFrame(rows, columns=["date"]+names)
    df.index = pd.PeriodIndex(pd.to_datetime(df.pop("date"), format="%Y%m"), freq="M")
    if df.index.has_duplicates or not df.index.is_monotonic_increasing:
        raise ValueError(f"{zipname}: duplicate or unsorted monthly factor dates")
    return df.astype(float).replace([-99.99, -999.0], np.nan) / 100

FF3 = ["Mkt-RF", "SMB", "HML"]
FF5 = FF3 + ["RMW", "CMA"]
FACTOR_COLUMNS = FF5 + ["RF"]
fac = read_french("F-F_Research_Data_5_Factors_2x3_CSV.zip", FACTOR_COLUMNS)
if not set(FACTOR_COLUMNS).issubset(fac.columns):
    raise ValueError(f"Required factor columns are missing: {set(FACTOR_COLUMNS) - set(fac.columns)}")
if fac.index.has_duplicates or not fac.index.is_monotonic_increasing:
    raise ValueError("Factor table contains duplicate or unsorted months")
if not np.isfinite(fac.to_numpy()).all():
    raise ValueError("Required monthly factor series contain missing/non-finite values")
if fac[FACTOR_COLUMNS].abs().to_numpy().max() >= 1 or fac["RF"].abs().max() >= 0.05:
    raise ValueError("Factor values are inconsistent with decimal monthly units")

W0, W1 = P["WIN"]
E0, E1 = P["EVAL"]
if (W0, W1) != ("2015-01", "2022-12"):
    raise ValueError("Estimation window violates the frozen assignment policy")
if (E0, E1) != ("2023-01", "2025-12"):
    raise ValueError("Evaluation window violates the frozen assignment policy")
policy_path = OUT/"frozen_policy.json"
if policy_path.exists():
    saved_policy = json.loads(policy_path.read_text(encoding="utf-8"))
    if tuple(saved_policy.get("estimation_window", ())) != (W0, W1):
        raise ValueError("Configured estimation period differs from saved frozen policy")
    if tuple(saved_policy.get("evaluation_window", ())) != (E0, E1):
        raise ValueError("Configured evaluation period differs from saved frozen policy")

expected_train = pd.period_range(W0, W1, freq="M")
Rw = ret_tr.loc[W0:W1]
Fw = fac.loc[W0:W1]
if not Rw.index.equals(Fw.index):
    raise ValueError("Asset returns and factor months are not exactly aligned")
if not Rw.index.equals(expected_train) or not Fw.index.equals(expected_train):
    raise ValueError("Estimation observations do not exactly match frozen monthly dates")
if len(Rw) != 96 or len(Rw) < 60:
    raise ValueError(f"Frozen estimation sample must contain 96 monthly observations; found {len(Rw)}")
if not np.isfinite(Rw.to_numpy()).all() or not np.isfinite(Fw[FACTOR_COLUMNS].to_numpy()).all():
    raise ValueError("Missing/non-finite return or factor observations in estimation window")

ex = Rw.sub(Fw["RF"], axis=0)
ann_geo = lambda r: (1+r).prod()**(12/len(r)) - 1
dq = pd.DataFrame({"first_price_date": [raw[t].index[0].date() for t in ASSETS],
                   "months_in_window": Rw.count().values,
                   "ann_return_total": [ann_geo(Rw[t]) for t in ASSETS],
                   "ann_return_price_only": [ann_geo(ret_pr.loc[W0:W1, t]) for t in ASSETS]}, index=ASSETS)
save_table(dq, "T01_data_quality")
print("Window:", Rw.index[0], "to", Rw.index[-1], "| n =", len(Rw), "| factors through:", fac.index[-1])


# Check `T01_data_quality.csv` for coverage and compare the total-return and price-only columns. Missing or misaligned estimation data should be resolved before interpreting the results.

# ## Source-file integrity check
# 
# This cell recalculates the SHA-256 hash for each file listed in `data/raw/source_record.json`, compares it with the saved hash, and stops if a file does not match. The results are recorded in `T00_source_record.csv`.
# 
# A hash mismatch means the input may have changed or been corrupted; investigate it before relying on the analysis.
# 
# The manifest was written on Windows, so its paths use backslashes. We convert them to `/` before hashing so the check runs on any operating system. This changes how the file is located, not what is hashed.

# In[3]:


import hashlib
rec = json.load(open(RAW/"source_record.json"))
chk = pd.DataFrame(rec["entries"])[["source","id","file","sha256"]]
chk["sha_ok"] = [hashlib.sha256((ROOT/f.replace("\\", "/")).read_bytes()).hexdigest() == h for f, h in zip(chk.file, chk.sha256)]
if not chk["sha_ok"].all():
    raise ValueError("Raw source hash verification failed; inspect T00_source_record before analysis")
print("Retrieved (UTC):", rec["retrieval_utc"], "| yfinance", rec["yfinance"], "| pandas", rec["pandas"], "| failed downloads:", rec["failures"] or "none")
save_table(chk.set_index("id"), "T00_source_record")


# In `T00_source_record.csv`, every `sha_ok` value should be true. The printed retrieval record should also show no download failures.

# ## Candidate investment universe
# 
# The candidate list contains ten US common stocks across eight sectors, plus SPY (a broad US market ETF and our benchmark) and USMV (a minimum-volatility ETF). The eligibility register cites SEC filings identifying the stocks' common shares, ticker, exchange, and issuer business on filing dates in 2022, with a secondary S&P 500 constituent snapshot dated 28 December 2022. Those records do not establish continued case-date listing or index membership on 31 December. Yahoo price history confirms trading coverage only.
# 
# There is also a selection-bias limitation: we chose companies with the benefit of knowing which names survived. We did not select stocks by obvious later-winner or later-loser rules, but that does not remove the bias.

# ## Security roles and eligibility evidence
# 
# This cell joins the candidate roles to `data/security_eligibility_evidence.csv` and saves the evidence, source URL, document date, verification status, limitations, and trading coverage to `T02_universe.csv`. The dated SEC evidence documents the stock listings on their filing dates, SPY's ticker/listing/objective in its 28 January 2022 prospectus, and USMV's ticker/listing/inception/index mandate in its 25 May 2021 filing. The evidence register marks case-date eligibility partial because none of these records establishes continued status on 31 December 2022; the stock-list corroboration is secondary and dated 28 December.
# 
# The configured universe meets the requested count and sector breadth. The evidence supports the listed facts as of each document date, but no ticker is marked fully verified for 31 December 2022. For the stocks, the business descriptions support sector/role context, not an investment mandate. Trading history is not eligibility evidence.

# In[4]:


roles = {"AAPL":("Info Tech","mega-cap growth"),"MSFT":("Info Tech","mega-cap growth/quality"),"JPM":("Financials","rate/credit-cycle cyclical"),
         "JNJ":("Health Care","defensive"),"UNH":("Health Care","defensive growth"),"XOM":("Energy","commodity/inflation hedge"),
         "PG":("Staples","defensive"),"HD":("Cons. Disc.","cyclical consumer"),"NEE":("Utilities","bond-like/rate sensitive"),
         "CAT":("Industrials","cyclical value"),"SPY":("Broad ETF","cap-weighted US market / benchmark"),"USMV":("Broad ETF","minimum-volatility mandate")}
uni = pd.DataFrame(roles, index=["sector","role"]).T
eligibility = pd.read_csv(ROOT / "data" / "security_eligibility_evidence.csv").set_index("ticker")
if eligibility.index.has_duplicates or set(eligibility.index) != set(ASSETS):
    raise ValueError("Eligibility register must contain exactly one evidence row for every configured ticker")
required_evidence = ["source_url", "document_date", "relevant_evidence", "verification_status", "limitation"]
if eligibility[required_evidence].isna().any().any() or eligibility[required_evidence].eq("").any().any():
    raise ValueError("Eligibility register contains missing source, date, evidence, status, or limitation")
if (pd.to_datetime(eligibility["document_date"]) > pd.Timestamp("2022-12-31")).any():
    raise ValueError("Eligibility evidence includes a document after the 2022-12-31 information cutoff")
uni["eligibility_evidence"] = eligibility["relevant_evidence"].reindex(ASSETS)
uni["eligibility_source"] = eligibility["source_url"].reindex(ASSETS)
uni["eligibility_source_date"] = eligibility["document_date"].reindex(ASSETS)
uni["eligibility_verification_status"] = eligibility["verification_status"].reindex(ASSETS)
uni["eligibility_limitation"] = eligibility["limitation"].reindex(ASSETS)
uni["corroborating_source_url"] = eligibility["corroborating_source_url"].reindex(ASSETS)
uni["corroborating_document_date"] = eligibility["corroborating_document_date"].reindex(ASSETS)
uni["trading_coverage"] = "Yahoo daily prices available over 2015-2022; see T01 and source record"
save_table(uni, "T02_universe")


# Review `T02_universe.csv` and its eligibility columns. Trading coverage should not be treated as proof of eligibility on the case date.

# ## 2. Bond valuation and payment funding
# 
# The 1-year and 2-year zero-coupon bonds provide spot rates directly. We bootstrap the 3-, 5-, and 8-year spots from coupon-bond prices, then linearly interpolate rates at unquoted maturities (4, 6, and 7 years). This interpolation is an assumption and affects Delta and Epsilon.
# 
# We test parallel shocks of +/-100 bp and +250 bp, as well as steepening and flattening scenarios that move from -50 bp at one year to +50 bp at eight years, or the reverse.

# ## Bond valuation, spot rates, duration, and convexity
# 
# Using the five fictional bonds and prices in the case, this cell builds their annual cash flows, calculates yields to maturity, and bootstraps spot rates in maturity order. It marks observed curve points separately from interpolated rates in `T03_spot_curve.csv`. It also calculates duration and convexity, checks them numerically, and compares those estimates with exact repricing under the selected shocks in `T04_bond_analytics.csv` and `T05_duration_vs_exact.csv`.
# 
# The case gives bond prices and contractual cash flows, but not a complete spot curve or resale history. We use the quoted prices and make the interpolation visible rather than inventing a historical bond-price series.

# In[5]:


bonds = pd.DataFrame({"mat":[1,2,3,5,8], "cpn":[0,0,4,3.5,4.5], "price":[958.77,922.78,1002.49,986.07,1040.71]},
                     index=["Alpha","Beta","Gamma","Delta","Epsilon"])
def cfs(b):
    t = np.arange(1, int(b["mat"])+1); c = np.full(len(t), b["cpn"]*10.0); c[-1] += 1000; return t, c
def price_ytm(b, y): t, c = cfs(b); return (c/(1+y)**t).sum()
def ytm(b): return brentq(lambda y: price_ytm(b, y)-b["price"], -0.05, 0.5)

# bootstrap spot curve with linear interpolation between knots
spots = {}
for n, b in bonds.iterrows():
    T = int(b["mat"]); t, c = cfs(b); known = sorted(spots)
    def f(s):
        curve_t = np.interp(t, known+[T], [spots[k] for k in known]+[s])
        return (c/(1+curve_t)**t).sum() - b["price"]
    spots[T] = brentq(f, -0.05, 0.5)
yrs = np.arange(1, 9); spot_v = np.interp(yrs, list(spots), list(spots.values()))
curve = lambda t: np.interp(t, yrs, spot_v)
fwd = [spot_v[0]] + [((1+spot_v[i])**(i+1)/(1+spot_v[i-1])**i - 1) for i in range(1, 8)]
save_table(pd.DataFrame({"spot":spot_v, "implied_forward":fwd, "observed": [y in spots for y in yrs]}, index=yrs), "T03_spot_curve")

rows = []
for n, b in bonds.iterrows():
    y = ytm(b); t, c = cfs(b); pv = c/(1+y)**t; p0 = b["price"]
    mac = (t*pv).sum()/p0; mod = mac/(1+y); cx = (t*(t+1)*c/(1+y)**(t+2)).sum()/p0
    d = 1e-4; up, dn = price_ytm(b, y+d), price_ytm(b, y-d)
    rows.append(dict(bond=n, maturity=b["mat"], coupon_pct=b["cpn"], price=p0, ytm=y, current_yield=b["cpn"]*10/p0,
                     spot_at_maturity=spots[int(b["mat"])], macaulay=mac, modified=mod, convexity=cx,
                     mod_dur_numeric=-(up-dn)/(2*p0*d), convexity_numeric=(up+dn-2*p0)/(p0*d*d)))
bt = save_table(pd.DataFrame(rows).set_index("bond"), "T04_bond_analytics")

# duration/convexity approximation vs exact repricing
rows = []
for n, b in bonds.iterrows():
    r = bt.loc[n]; t, c = cfs(b)
    for d in [0.01, -0.01, 0.025]:
        exact_y = price_ytm(b, r["ytm"]+d)/b["price"]-1
        exact_curve = (c/(1+curve(t)+d)**t).sum()/b["price"]-1
        dur = -r["modified"]*d; dc = dur + 0.5*r["convexity"]*d**2
        rows.append(dict(bond=n, shock_bp=d*1e4, duration_only=dur, duration_convexity=dc, exact_yield_reprice=exact_y,
                         exact_spot_curve_reprice=exact_curve, error_dur_conv=dc-exact_y))
save_table(pd.DataFrame(rows).set_index(["bond","shock_bp"]), "T05_duration_vs_exact")


# Review `T03_spot_curve.csv`, `T04_bond_analytics.csv`, and `T05_duration_vs_exact.csv`. The spot-curve file distinguishes quoted points from interpolated ones; the repricing file shows how duration and convexity estimates compare with exact prices.

# ## Funding the commitments with bonds
# 
# This cell schedules bond cash flows through year five and maps the 2024 and 2027 payments to their due dates. A non-negative linear program finds the lowest-cost bond purchases that cover the cumulative payments. We round holdings up to whole units, check interim cash balances assuming zero cash carry, and save the funding schedule and holdings in `T06_funding_cashflows.csv` and `T07_bond_holdings.csv`.
# 
# We then reprice the selected assets and payment liabilities under the base curve and the parallel and curve-shape scenarios. `T08_rate_scenarios_funding.csv` also reports present value and duration context.
# 
# This approach matches contractual cash flows rather than relying on historical bond returns. It assumes default-free case bonds and zero cash carry. We exclude Epsilon because its later cash flows would require a resale-price assumption. The remaining cash balances are small, not a substantial liquidity cushion; scenario sizes and reinvestment assumptions are team choices.

# In[6]:


# ---- funding plan: cheapest set of bonds whose cash flows cover both payments, surplus cash earns 0% (conservative) ----
H = 5; names = ["Alpha","Beta","Gamma","Delta"]       # Epsilon excluded: only 5y of its cash flows usable without a resale-price assumption
cfm = np.zeros((len(names), H))
for i, n in enumerate(names): t, c = cfs(bonds.loc[n]); cfm[i, :len(t)] = c
pay = np.zeros(H)
for yr, a in P["PAY"].items(): pay[yr-1] = a
cum = np.tril(np.ones((H, H)))
res = linprog(c=bonds.loc[names, "price"].values, A_ub=-(cum@cfm.T), b_ub=-(cum@pay), bounds=[(0, None)]*len(names), method="highs")
if not res.success:
    raise RuntimeError(f"Bond cash-flow funding optimization failed: {res.message}")
units = np.ceil(res.x - 1e-9)                          # whole bonds, rounding up keeps feasibility
bond_cost = float((units*bonds.loc[names, "price"].values).sum())
inflow = cfm.T@units
bal = np.cumsum(inflow - pay); assert bal.min() > -1e-6
fund_tbl = pd.DataFrame({"bond_cash_in": inflow, "payment": pay, "closing_cash_0pct": bal}, index=range(2023, 2028))
save_table(fund_tbl, "T06_funding_cashflows")
hold = pd.DataFrame({"units": units, "price": bonds.loc[names, "price"].values}, index=names); hold["cost_usd"] = hold.units*hold.price
save_table(hold, "T07_bond_holdings")

shifts = {"base": lambda t: 0*t, "parallel +100bp": lambda t: 0.01+0*t, "parallel -100bp": lambda t: -0.01+0*t,
          "parallel +250bp": lambda t: 0.025+0*t,
          "steepener (-50bp 1y -> +50bp 8y)": lambda t: -0.005+0.01*(t-1)/7, "flattener (+50bp 1y -> -50bp 8y)": lambda t: 0.005-0.01*(t-1)/7}
def asset_pv(sh): return sum(units[i]*(lambda tc: (tc[1]/(1+curve(tc[0])+sh(tc[0]))**tc[0]).sum())(cfs(bonds.loc[n])) for i, n in enumerate(names))
def liab_pv(sh): return sum(pay[k]/(1+curve(k+1)+sh(k+1))**(k+1) for k in range(H) if pay[k] > 0)
rows = []
for k, sh in shifts.items():
    a, l = asset_pv(sh), liab_pv(sh); rows.append(dict(scenario=k, assets_pv=a, liabilities_pv=l, surplus=a-l))
sc = pd.DataFrame(rows).set_index("scenario"); sc["surplus_change"] = sc.surplus - sc.loc["base","surplus"]
save_table(sc, "T08_rate_scenarios_funding")
tt = np.array([k+1 for k in range(H) if pay[k] > 0]); w_l = np.array([pay[k-1]/(1+curve(k))**k for k in tt])
print("Liability PV (spot curve): %.0f | bond cost (0%% carry): %.0f | surplus cash end-2027: %.0f" % (liab_pv(shifts['base']), bond_cost, bal[-1]))
print("Liability Macaulay duration: %.2f yrs" % ((tt*w_l).sum()/w_l.sum()))
def mac_pv(n):
    t_, c_ = cfs(bonds.loc[n]); pv_ = c_/(1+curve(t_))**t_; return (t_*pv_).sum(), pv_.sum()
print("Matching-bond portfolio Macaulay duration: %.2f yrs" % (sum(units[i]*mac_pv(n)[0] for i, n in enumerate(names))/sum(units[i]*mac_pv(n)[1] for i, n in enumerate(names))))


# Review the payment-date balances in `T06_funding_cashflows.csv` and the holdings in `T07_bond_holdings.csv`. The scenario results are in `T08_rate_scenarios_funding.csv`; note the small cash residuals and the assumptions behind each rate shock.

# ## 3. Growth sleeve and real-value goal
# 
# We hold the matching bonds to maturity, so the two payments do not depend on equity-market performance, assuming the case bonds are default-free. The real-value goal is at least USD 8 million at 31 December 2030, after eight years of inflation. Because the case does not give an inflation rate, we use 2.5% in the base case and show 2%-4% scenarios. This is a judgment: inflation at the end of 2022 was much higher.
# 
# We interpret ?losses approaching 15%? as a one-year 95% loss of no more than 15% of the total fund. Under the hold-to-maturity assumption, this modeled loss comes from the growth sleeve. We also report the worst historical 12-month loss and maximum drawdown; these are different measures.

# ## Growth allocation and required return
# 
# This cell uses the one-year spot rate as the risk-free rate and calculates how much remains for growth after the bond purchases and cash reserve. It estimates the initial trading costs and, for inflation assumptions of 2%, 2.5%, 3%, and 4%, calculates the 2030 nominal amount equivalent to the USD 8 million real goal and the annual return needed to reach it. Results are saved in `T09_goal_requirements.csv`.
# 
# This translates the real goal into a nominal hurdle; it is not a return forecast. The inflation assumption and zero cash return are not specified in the case, so the base case needs to be justified.

# In[7]:


rf_ann = spots[1]                                       # 1y zero yield: observed risk-free rate at the decision date
G_total = P["FUND"] - bond_cost - P["CASH_BUFFER"]       # growth sleeve
tc_initial = P["TC"]*G_total
other = P["CASH_BUFFER"] - tc_initial + bal[-1]          # buffer net of costs + leftover bond cash, 0% to 2030
share = G_total/P["FUND"]
def need_growth(infl): return P["GOAL_REAL"]*(1+infl)**P["GOAL_YEARS"] - other
def req_ret(infl): return (need_growth(infl)/G_total)**(1/P["GOAL_YEARS"]) - 1
goal_tbl = pd.DataFrame({"inflation": [0.02,0.025,0.03,0.04]})
goal_tbl["nominal_goal_2030"] = P["GOAL_REAL"]*(1+goal_tbl.inflation)**P["GOAL_YEARS"]
goal_tbl["required_growth_return_pa"] = goal_tbl.inflation.map(req_ret)
save_table(goal_tbl.set_index("inflation"), "T09_goal_requirements")
print("Growth sleeve: %.0f (%.1f%% of fund) | risk-free (1y zero): %.2f%% | required growth return at base inflation: %.2f%%" %
      (G_total, share*100, rf_ann*100, req_ret(P["INFLATION"])*100))


# Use `T09_goal_requirements.csv` to compare the required return under each inflation assumption. These figures are hurdles, not predicted or guaranteed returns.

# ## 4. Growth-portfolio decision
# 
# We estimate expected returns using CAPM: the one-year spot rate plus each security's beta multiplied by a 5% ERP. The ERP is our forward-looking assumption, not a return forecast supplied by the case. We show historical means only in the alternative allocation because they are noisy estimates.
# 
# The optimizer maximizes mean-variance utility for a long-only, fully invested portfolio, with a cap on each security's weight. We compare sample-covariance risk estimates with a single-index model using the French Mkt-RF series. Risk aversion of 4, the 25% cap, and 10 bp one-way trading costs are team judgments. The frozen policy rebalances when any target weight drifts by more than 5 percentage points.

# ## Expected returns, risk models, and portfolio weights
# 
# This cell estimates each security's beta and alpha from monthly excess returns against Mkt-RF, then builds annualized single-index and sample covariance matrices. Expected returns use the one-year spot rate plus beta times the assumed ERP. The optimizer checks that its long-only weights sum to one and respect the per-security cap.
# 
# It saves risk-aversion sensitivity in `T10`, compares the two risk models in `T11` and `T12`, and records a historical-Sharpe alternative using the full and most recent 60-month samples in `T13`. `F01_weights.png` plots the allocations.
# 
# The comparison shows how the estimates and assumptions affect the proposed weights. The historical-Sharpe portfolio is an alternative, not our frozen decision rule, and a solver's result is not by itself a recommendation.

# In[8]:


mkt = Fw["Mkt-RF"]
beta = ex.apply(lambda s: s.cov(mkt)/mkt.var())
alpha_i = ex.mean() - beta*mkt.mean()
resid = ex - pd.DataFrame(np.outer(mkt, beta), index=ex.index, columns=ex.columns) - alpha_i
S_si = pd.DataFrame(np.outer(beta, beta)*mkt.var() + np.diag(resid.var()), index=ASSETS, columns=ASSETS)*12
S_sa = ex.cov()*12
mu = rf_ann + beta*P["ERP"]

def mv_opt(mu, S, A, maxw):
    n = len(mu); m = mu.values; Sv = S.values
    if n * maxw < 1:
        raise ValueError(f"Infeasible per-security cap {maxw} for {n} assets")
    r = minimize(lambda w: -(w@m - 0.5*A*w@Sv@w), np.ones(n)/n, jac=lambda w: -(m - A*Sv@w), bounds=[(0, maxw)]*n,
                 constraints=[{"type":"eq","fun":lambda w: w.sum()-1,"jac":lambda w: np.ones(n)}], method="SLSQP")
    if not r.success:
        raise RuntimeError(f"Mean-variance optimization failed: {r.message}")
    if not np.isclose(r.x.sum(), 1.0) or np.any(r.x < -1e-8) or np.any(r.x > maxw + 1e-8):
        raise RuntimeError("Mean-variance optimizer returned weights outside the mandate constraints")
    return pd.Series(r.x, index=mu.index)
def stats_p(w, S, mu):
    m = float(w@mu); s = float(np.sqrt(w@S@w)); return dict(exp_return=m, vol=s, loss95_fund=-(m-1.645*s)*share)
effN = lambda w: 1/(w**2).sum()

# (a) effect of risk aversion
rows = []
for A in [1, 2, 4, 6, 8, 12]:
    w = mv_opt(mu, S_si, A, P["MAX_W"]); rows.append(dict(A=A, **stats_p(w, S_si, mu), eff_N=effN(w), **{f"w_{t}": w[t] for t in ASSETS}))
save_table(pd.DataFrame(rows).set_index("A"), "T10_risk_aversion")

# (b) recommended: single-index risk, chosen A; same universe under sample covariance for comparison
A = P["RISK_AVERSION"]
w_rec = mv_opt(mu, S_si, A, P["MAX_W"]); w_sa = mv_opt(mu, S_sa, A, P["MAX_W"])
cmp_ = pd.DataFrame({"single_index": w_rec, "sample_cov": w_sa}); cmp_["diff"] = cmp_.single_index - cmp_.sample_cov
save_table(cmp_, "T11_weights_si_vs_sample")
cross = pd.DataFrame({"w_single_index": stats_p(w_rec, S_si, mu) | {"vol_under_sample": float(np.sqrt(w_rec@S_sa@w_rec))},
                      "w_sample_cov": stats_p(w_sa, S_sa, mu) | {"vol_under_sample": float(np.sqrt(w_sa@S_sa@w_sa))}})
cross.loc["vol_under_single_index"] = [float(np.sqrt(w_rec@S_si@w_rec)), float(np.sqrt(w_sa@S_si@w_sa))]
cross.loc["turnover_si_vs_sample"] = [0.5*(w_rec-w_sa).abs().sum()]*2
save_table(cross, "T12_risk_estimate_comparison")
cmp_[["single_index","sample_cov"]].plot.bar(figsize=(9,3.5), title="Growth sleeve weights: single-index vs sample covariance"); save_fig("F01_weights")

# (c) rejected alternative: Eta - highest historical Sharpe, sample covariance, long-only
def max_sharpe(exm):
    mu_h = exm.mean().values*12; Sh = exm.cov().values*12; n = len(mu_h)
    r = minimize(lambda w: -(w@mu_h)/np.sqrt(w@Sh@w), np.ones(n)/n, bounds=[(0,1)]*n,
                 constraints=[{"type":"eq","fun":lambda w: w.sum()-1}], method="SLSQP")
    if not r.success:
        raise RuntimeError(f"Historical Sharpe optimization failed: {r.message}")
    return pd.Series(r.x, index=exm.columns)
w_alt = max_sharpe(ex); w_alt60 = max_sharpe(ex.iloc[-60:])
alt = pd.DataFrame({"eta_full_window": w_alt, "eta_last60m": w_alt60, "recommended": w_rec})
alt.loc["effective_N"] = [effN(w_alt), effN(w_alt60), effN(w_rec)]
alt.loc["instability (half-L1 full vs 60m)"] = [0.5*(w_alt-w_alt60).abs().sum(), np.nan, np.nan]
save_table(alt, "T13_rejected_alternative")
print("Rejected alt under common inputs:", stats_p(w_alt, S_si, mu), "| hist Sharpe:", float((w_alt@ex.mean()*12)/np.sqrt(w_alt@S_sa@w_alt)))


# Review `T10_risk_aversion.csv` through `T13_rejected_alternative.csv` and `F01_weights.png`. Compare the weights, concentration, risk estimates, and how the historical-Sharpe allocation changes across samples; do not rely on the optimizer output alone.

# ## Risk checks, sensitivity, and dollar allocation
# 
# This cell reports the worst rolling 12-month sleeve return, historical drawdown, the sleeve's share of total-fund loss, and a model-based one-year 95% loss estimate in `T14`. It calculates component risk contributions and betas (`T15`), tests alternative ERP and security-cap assumptions (`T16`), and lays out the bond, growth, cash, and cost amounts (`T17`). A final check confirms that the dollar amounts add up to USD 12 million.
# 
# The 15% loss figure is a diagnostic comparison, not an optimizer constraint. The modeled 95% loss assumes normally distributed returns; historical losses and drawdowns are different measures. Being below the selected threshold does not prove that the portfolio is safe or that trustees approved it. Sensitivity analysis shows the effects of changing assumptions, not that our chosen values are objectively correct.

# In[9]:


# risk contributions, historical sleeve risk, trade-off checks
rp = Rw@w_rec; wealth = (1+rp).cumprod()
hist = pd.Series({"worst_12m_sleeve": ((1+rp).rolling(12).apply(np.prod, raw=True)-1).min(),
                  "max_drawdown_sleeve": (wealth/wealth.cummax()-1).min(),
                  "worst_12m_on_total_fund": ((1+rp).rolling(12).apply(np.prod, raw=True)-1).min()*share,
                  "model_loss95_on_total_fund": stats_p(w_rec, S_si, mu)["loss95_fund"],
                  "expected_return_sleeve": stats_p(w_rec, S_si, mu)["exp_return"],
                  "required_return_base_inflation": req_ret(P["INFLATION"])})
save_table(hist.to_frame("value"), "T14_recommended_checks")
print("Loss diagnostic below threshold:", hist["model_loss95_on_total_fund"] <= P["LOSS_LIMIT"], "| expected return >= required:", hist["expected_return_sleeve"] >= hist["required_return_base_inflation"])
rc = w_rec*(S_si@w_rec)/(w_rec@S_si@w_rec)
save_table(pd.DataFrame({"weight": w_rec, "risk_contribution": rc, "beta": beta}), "T15_risk_contributions")

# sensitivity: ERP and cap
rows = {}
for e in [0.03, 0.04, 0.05, 0.06, 0.07]: rows[f"ERP={e:.0%}"] = mv_opt(rf_ann+beta*e, S_si, A, P["MAX_W"])
for cap in [0.15, 0.35, 1.0]: rows[f"cap={cap:.0%}"] = mv_opt(mu, S_si, A, cap)
save_table(pd.DataFrame(rows), "T16_sensitivity")

# initial dollar allocation (full USD 12m)
alloc = pd.concat([hold["cost_usd"].rename("usd"), (w_rec*G_total).rename("usd")]) 
alloc.loc["Cash buffer"] = P["CASH_BUFFER"] - tc_initial; alloc.loc["Trading costs (growth buy)"] = tc_initial
alloc = alloc.to_frame(); alloc["pct_of_fund"] = alloc.usd/P["FUND"]
assert abs(alloc.usd.sum() - P["FUND"]) < 1, alloc.usd.sum()
save_table(alloc, "T17_initial_allocation")


# Check `T14_recommended_checks.csv` through `T17_initial_allocation.csv`. Confirm that the allocation totals USD 12 million, and distinguish the loss diagnostic from a binding limit.

# ## 5. Market and factor exposures
# 
# We compare CAPM (Mkt-RF), FF3 (Mkt-RF, SMB, HML), and FF5 (Mkt-RF, SMB, HML, RMW, CMA) for the growth portfolio and selected securities. HAC standard errors use three lags. Alpha is the monthly intercept multiplied by 12; its t-statistic is based on the unannualized monthly estimate.
# 
# For our growth portfolio, the FF3 market beta is 0.715 (t=17.45), SMB beta is -0.335 (t=-6.50), and HML beta is 0.012 (t=0.29). Under FF5, RMW is 0.272 (t=3.58) and CMA is 0.296 (t=4.06). Annualized alpha falls from 5.02% under CAPM to 4.18% under FF3 and 2.34% under FF5; the FF5 t-statistic is 1.58. The estimate is uncertain, so we do not use it as evidence of persistent skill. AAPL has positive market exposure and negative HML exposure; XOM has positive HML exposure. These are historical associations, not causal effects. Expected returns remain CAPM-based; the factor regressions describe exposures rather than forecast persistent alpha.

# ## CAPM, FF3, and FF5 regressions
# 
# This cell checks the factor specifications, then fits each model to the growth portfolio and two selected stocks over the same 96-month estimation window. It uses OLS with three-lag HAC standard errors, subtracts RF once from total returns, and saves coefficients, alphas, t-statistics, fit statistics, and model details in `T18_factor_regressions.csv`. It also reports estimation-window factor premia (`T19`), compares model-based expected returns (`T20`), and tests FF5 residual alpha over the separate 2023-2025 period (`T21`).
# 
# The results show whether the return explanation changes across models and make uncertainty around alpha visible. The sample is only 96 months, and the chosen factor-file vintage and factor premia matter. An estimated alpha is not proof of persistent skill.

# In[10]:


models = {"CAPM": ["Mkt-RF"], "FF3": FF3, "FF5": FF5}
expected_models = {
    "CAPM": ("Mkt-RF",),
    "FF3": ("Mkt-RF", "SMB", "HML"),
    "FF5": ("Mkt-RF", "SMB", "HML", "RMW", "CMA"),
}
if {name: tuple(cols) for name, cols in models.items()} != expected_models:
    raise ValueError("Factor regression specifications do not match CAPM, FF3, and FF5")
expected_regression_index = pd.period_range(W0, W1, freq="M")
def run_reg(y, cols):
    if not Fw.index.equals(expected_regression_index) or not y.index.equals(expected_regression_index):
        raise ValueError("Regression dates must exactly match the frozen 96-month 2015-01 to 2022-12 estimation window")
    if len(y) != 96:
        raise ValueError(f"Frozen factor regression requires 96 monthly observations; found {len(y)}")
    if not set(cols).issubset(Fw.columns):
        raise ValueError(f"Regression is missing required factors: {set(cols) - set(Fw.columns)}")
    if not np.isfinite(y.to_numpy()).all() or not np.isfinite(Fw[cols].to_numpy()).all():
        raise ValueError("Regression contains missing or non-finite return/factor observations")
    r = sm.OLS(y, sm.add_constant(Fw[cols])).fit(cov_type="HAC", cov_kwds={"maxlags": 3})
    row = {"alpha_ann": r.params["const"]*12, "alpha_t": r.tvalues["const"],
           "R2": r.rsquared, "adjR2": r.rsquared_adj, "nobs": int(r.nobs),
           "sample_start": str(y.index.min()), "sample_end": str(y.index.max()),
           "frequency": "monthly", "factor_columns": ", ".join(cols)}
    for c in cols:
        row[f"b_{c}"] = r.params[c]
        row[f"t_{c}"] = r.tvalues[c]
    return row, r
if not np.isclose(w_rec.sum(), 1.0, atol=1e-10):
    raise ValueError("Frozen growth sleeve must be fully invested before subtracting RF once")
ex_g = (Rw@w_rec) - Fw["RF"]
items = {"Growth portfolio": ex_g, **{s: ex[s] for s in P["FACTOR_STOCKS"]}}
rows, fits = [], {}
for nm, y in items.items():
    for mn, cols in models.items():
        row, r = run_reg(y, cols)
        fits[(nm, mn)] = r
        rows.append(dict(asset=nm, model=mn, **row))
save_table(pd.DataFrame(rows).set_index(["asset", "model"]), "T18_factor_regressions")

prem = pd.DataFrame({"premium_ann": Fw[FF5].mean()*12, "t_stat": Fw[FF5].mean()/(Fw[FF5].std()/np.sqrt(len(Fw)))})
save_table(prem, "T19_factor_premia_window")
rows = []
for nm in items:
    r3 = fits[(nm, "FF3")]
    r5 = fits[(nm, "FF5")]
    capm = fits[(nm, "CAPM")]
    rows.append(dict(asset=nm, capm_exp_ret=rf_ann+capm.params["Mkt-RF"]*P["ERP"],
                     ff3_exp_ret_hist_premia=rf_ann+sum(r3.params[c]*prem.loc[c, "premium_ann"] for c in FF3),
                     ff5_exp_ret_hist_premia=rf_ann+sum(r5.params[c]*prem.loc[c, "premium_ann"] for c in FF5),
                     ff3_exp_ret_mkt_at_ERP=rf_ann+r3.params["Mkt-RF"]*P["ERP"],
                     ff5_exp_ret_mkt_at_ERP=rf_ann+r5.params["Mkt-RF"]*P["ERP"]))
save_table(pd.DataFrame(rows).set_index("asset"), "T20_expected_returns_by_model")

# Evaluation observations are reserved for this post-estimation check, not model or strategy selection.
ev = ret_tr.loc[E0:E1]
Fe = fac.loc[E0:E1]
idx = ev.index.intersection(Fe.index)
expected_eval = pd.period_range(E0, E1, freq="M")
if not idx.equals(expected_eval) or not ev.index.equals(expected_eval) or not Fe.index.equals(expected_eval):
    raise ValueError("Evaluation returns and factors must exactly match the frozen 2023-01 to 2025-12 window")
rows = []
for nm in items:
    y = ((ev.loc[idx]@w_rec) if nm == "Growth portfolio" else ev.loc[idx, nm]) - Fe.loc[idx, "RF"]
    r = fits[(nm, "FF5")]
    fitted = sum(r.params[c]*Fe.loc[idx, c] for c in FF5)
    e = y - fitted
    if not np.isfinite(e.to_numpy()).all():
        raise ValueError(f"Non-finite out-of-sample regression residuals for {nm}")
    oos_fit = sm.OLS(e, np.ones((len(e), 1))).fit(cov_type="HAC", cov_kwds={"maxlags": 3})
    rows.append(dict(asset=nm, months=len(idx), oos_alpha_ann=e.mean()*12,
                     t_stat_hac=float(np.asarray(oos_fit.tvalues).reshape(-1)[0]), t_stat_method="HAC, 3 lags",
                     in_sample_alpha_ann=r.params["const"]*12))
save_table(pd.DataFrame(rows).set_index("asset"), "T21_oos_alpha_check")


# Review `T18_factor_regressions.csv` through `T21_oos_alpha_check.csv`. Interpret the factor loadings alongside their HAC uncertainty; do not treat estimated alpha as persistent skill.

# ## 6. Out-of-sample comparison: 2023-2025
# 
# The growth-portfolio weights are frozen at 31 December 2022. At each December month-end, the portfolio rebalances only if any weight has drifted by more than 5 percentage points. We charge 10 bp on one-way turnover, including the initial purchase, and apply the same costs to SPY. None of the later-period data are used in the initial decision. `T22` records the number of rebalances.

# ## Frozen portfolio and benchmark evaluation
# 
# This cell checks the 36 monthly observations from 2023-2025 and applies the frozen strategy, including initial and rebalance costs. It evaluates our proposed portfolio, SPY, the historical-Sharpe alternative, and the sample-covariance portfolio. The comparison reports cumulative and annualized return, volatility, Sharpe ratio, drawdown, and worst 12-month return. Results and monthly returns are saved in `T22` and `T25`, with a value chart in `F02_evaluation.png`.
# 
# Using a period separate from the initial estimation helps us test the frozen policy without changing it based on later returns. This is a retrospective three-year comparison, not evidence that the eight-year goal will be met. The rebalance trigger and cost rate are assumptions and should agree with the dated decision record.

# In[11]:


Re = ret_tr.loc[E0:E1, ASSETS]
if Re.isna().any().any() or not np.isfinite(Re.to_numpy()).all():
    raise ValueError("Evaluation return panel contains missing or non-finite observations")
REBALANCE_DRIFT = 0.05
def run_strategy(w, R, tc, drift_limit=REBALANCE_DRIFT):
    w = w.reindex(R.columns).fillna(0).to_numpy(dtype=float)
    if not np.isclose(w.sum(), 1.0, atol=1e-10) or np.any(w < -1e-10):
        raise ValueError("Backtest strategy weights must be nonnegative and sum to one")
    if not 0 <= tc < 1 or not 0 <= drift_limit < 1:
        raise ValueError("Transaction cost or rebalance drift threshold is outside its valid range")
    pos = w*(1-tc); prev = 1.0; out = []; rebalance_count = 0
    for d, row in zip(R.index, R.to_numpy()):
        pos = pos*(1+row); v = pos.sum()
        if v <= 0 or not np.isfinite(v):
            raise ValueError(f"Invalid portfolio value during evaluation at {d}")
        drift = np.max(np.abs(pos/v-w))
        if d.month == 12 and drift > drift_limit:
            cost = tc*np.abs(w*v-pos).sum()
            v -= cost
            pos = w*v
            rebalance_count += 1
        out.append(v/prev-1); prev = v
    return pd.Series(out, index=R.index), rebalance_count
def perf(r, rf):
    n = len(r); cum = (1+r).prod()-1; vol = r.std()*np.sqrt(12); e = (r-rf.reindex(r.index)).dropna(); wl = (1+r).cumprod()
    return dict(cumulative=cum, ann_return=(1+cum)**(12/n)-1, ann_vol=vol, sharpe=e.mean()*12/vol,
                max_drawdown=(wl/wl.cummax()-1).min(), worst_12m=((1+r).rolling(12).apply(np.prod, raw=True)-1).min())
bench_w = pd.Series({P["BENCH"]: 1.0})
strats = {"Recommended (frozen)": w_rec, "Benchmark SPY": bench_w, "Rejected: Eta max-Sharpe": w_alt, "Sample-cov MV": w_sa}
strategy_results = {k: run_strategy(w, Re, P["TC"]) for k, w in strats.items()}
rets = {k: result[0] for k, result in strategy_results.items()}
tab = pd.DataFrame({k: perf(r, fac["RF"]) for k, r in rets.items()}).T
act = rets["Recommended (frozen)"] - rets["Benchmark SPY"]
tab["tracking_error_vs_bench"] = [np.nan if k == "Benchmark SPY" else (rets[k]-rets["Benchmark SPY"]).std()*np.sqrt(12) for k in tab.index]
tab["active_return_ann_vs_bench"] = [np.nan if k == "Benchmark SPY" else (rets[k]-rets["Benchmark SPY"]).mean()*12 for k in tab.index]
tab["rebalance_count"] = [strategy_results[k][1] for k in tab.index]
save_table(tab, "T22_evaluation_2023_2025")
evaluation_returns = pd.DataFrame(rets, index=Re.index)
evaluation_returns.index.name = "date"
if not evaluation_returns.index.equals(pd.period_range(E0, E1, freq="M")):
    raise ValueError("Monthly evaluation outputs do not match the frozen 2023-01 to 2025-12 window")
save_table(evaluation_returns, "T25_evaluation_monthly_returns")
pd.DataFrame({k: (1+r).cumprod() for k, r in rets.items()}).set_index(Re.index.to_timestamp()).plot(figsize=(9,4), title="Growth value of $1, 2023-2025 (frozen strategies)")
save_fig("F02_evaluation")
print("Worst 12m of recommended sleeve x share of fund:", tab.loc["Recommended (frozen)","worst_12m"]*share)
print("Rebalance rule:", f"December only when max absolute weight drift > {REBALANCE_DRIFT:.0%}")
print("NOTE: 3 years of results do not show that the 8-year goal is achieved.")


# Review `T22_evaluation_2023_2025.csv`, `T25_evaluation_monthly_returns.csv`, and `F02_evaluation.png`. Discuss the portfolio's performance relative to SPY alongside its risk statistics.

# ## 7. Conditions that could change the conclusion
# 
# We test two thresholds: the ERP below which expected growth return falls short of the required return, and the inflation rate above which the goal is out of reach in expectation. Goal probabilities use a lognormal approximation for the growth sleeve with constant weights; they ignore costs and rebalancing, so they are planning scenarios rather than guarantees or a full transaction-cost simulation.
# 
# Under the base assumptions, the probability in `T23` is below 75%, and the 25th-percentile real value in `T24` is below the USD 8 million goal. These thresholds affect the growth-goal conclusion, not the bond-funded payment plan.

# ## Reversal thresholds and goal scenarios
# 
# This cell solves for the ERP and inflation assumptions at which expected growth return crosses the required return, saving the thresholds in `T26_reversal_thresholds.csv`. It also uses a lognormal approximation to estimate goal probabilities across ERP and inflation scenarios (`T23_goal_probability.csv`) and percentiles of real fund value (`T24_real_value_distribution.csv`).
# 
# The thresholds show where the model's conclusion changes; they do not predict what will happen. The probabilities depend on the return and inflation assumptions and the lognormal approximation, so they should be read as scenarios, not precise forecasts.

# In[12]:


beta_p = float(w_rec@beta); sig_p = float(np.sqrt(w_rec@S_si@w_rec)); T = P["GOAL_YEARS"]
erp_star = (req_ret(P["INFLATION"]) - rf_ann)/beta_p
infl_star = brentq(lambda i: req_ret(i) - (rf_ann + beta_p*P["ERP"]), 0.0, 0.25)
print("Threshold ERP (at base inflation): %.2f%% | threshold inflation (at base ERP): %.2f%%" % (erp_star*100, infl_star*100))
thresholds = pd.DataFrame([{"base_inflation": P["INFLATION"], "erp_threshold": erp_star, "base_erp": P["ERP"], "inflation_threshold": infl_star, "required_growth_return": req_ret(P["INFLATION"]), "expected_growth_return": rf_ann + beta_p*P["ERP"]}], index=["expected-growth-goal crossover"])
save_table(thresholds, "T26_reversal_thresholds")
def logn(mu_p):
    s2 = np.log(1+sig_p**2/(1+mu_p)**2); return np.log(1+mu_p) - s2/2, s2
def p_goal(erp, infl):
    mL, s2 = logn(rf_ann + beta_p*erp)
    return 1 - norm.cdf((np.log(need_growth(infl)/G_total) - mL*T)/np.sqrt(s2*T))
grid = pd.DataFrame({f"infl={i:.1%}": [p_goal(e, i) for e in [0.03,0.04,0.05,0.06]] for i in [0.02,0.025,0.03,0.04]},
                    index=[f"ERP={e:.0%}" for e in [0.03,0.04,0.05,0.06]])
save_table(grid, "T23_goal_probability")
mL, s2 = logn(rf_ann + beta_p*P["ERP"]); q = lambda z: G_total*np.exp(mL*T + z*np.sqrt(s2*T))
real = lambda g: (g + other)/(1+P["INFLATION"])**T
pct = pd.DataFrame({"real_fund_value_dec2022_usd": [real(q(norm.ppf(p))) for p in [0.10, 0.25, 0.50]]}, index=["P10","P25","P50"])
save_table(pct, "T24_real_value_distribution")
print("Real goal supported with ~75%% probability: USD %.2fm (vs 8.00m target)" % (real(q(norm.ppf(0.25)))/1e6))


# Use `T23_goal_probability.csv`, `T24_real_value_distribution.csv`, and `T26_reversal_thresholds.csv` to review the goal scenarios. Interpret probabilities and thresholds only in light of their assumptions.

# ## 8. Policy record and monitoring
# 
# The dated decision record should track payment funding, interest-rate and curve changes against the scenarios, growth-sleeve drawdowns, inflation against the 2.5% base case, ERP and valuations, factor exposures, and the December rebalancing trigger (a drift of more than 5 percentage points).
# 
# The 2.5% inflation assumption, 5% ERP, risk aversion of 4, 15% loss interpretation, 25% security cap, and 10 bp trading cost are team judgments. The case does not prescribe them.

# ## Save the policy snapshot and run final checks
# 
# This cell saves the selected assumptions, bond holdings, growth weights, dollar allocation, benchmark, estimation and evaluation windows, and rebalance rule to `frozen_policy.json`. It will not replace an existing snapshot with different values; use a new output tag for a revised policy.
# 
# The final checks review the data hashes, regression coverage and specifications, HAC reporting, rebalance counts, and portfolio weights. They help catch inconsistencies but do not replace the separate decision log. Other tables and figures are written before this final check, so preserve the original output folder when testing a revision.

# In[13]:


frozen = {"params": {k: (v if not isinstance(v, dict) else {str(a): b for a, b in v.items()}) for k, v in P.items()},
          "bond_units": hold["units"].to_dict(), "growth_weights": w_rec.round(6).to_dict(), "growth_usd": float(G_total),
          "cash_buffer_net": float(P["CASH_BUFFER"]-tc_initial), "rebalance_rule": "each December to frozen weights; trade if drift > 5pp",
          "benchmark": P["BENCH"], "estimation_window": list(P["WIN"]), "evaluation_window": list(P["EVAL"])}
policy_path = OUT/"frozen_policy.json"
frozen = json.loads(json.dumps(frozen, default=float))
if policy_path.exists():
    saved_policy = json.loads(policy_path.read_text(encoding="utf-8"))
    if saved_policy != frozen:
        raise ValueError(f"Refusing to overwrite frozen policy at {policy_path}; set TAG to a new revision and compare against outputs/original")
else:
    policy_path.write_text(json.dumps(frozen, indent=2), encoding="utf-8")
print(sorted(p.name for p in OUT.iterdir()))
source = json.loads((RAW/"source_record.json").read_text(encoding="utf-8"))
if source["failures"]:
    raise ValueError(f"Raw source retrieval failures remain: {source['failures']}")
if not chk["sha_ok"].all():
    raise ValueError("Raw source hashes do not all match the recorded source manifest")
reg = pd.read_csv(OUT/"T18_factor_regressions.csv")
expected_factor_sets = {"CAPM": "Mkt-RF", "FF3": "Mkt-RF, SMB, HML", "FF5": "Mkt-RF, SMB, HML, RMW, CMA"}
if set(reg["model"]) != set(expected_factor_sets) or len(reg) != 9:
    raise ValueError("Regression output must contain CAPM, FF3, and FF5 for all three assets")
for model, factors in expected_factor_sets.items():
    subset = reg.loc[reg["model"] == model]
    if len(subset) != 3 or not subset["factor_columns"].eq(factors).all():
        raise ValueError(f"Incorrect {model} regression rows or factor columns")
if not reg["nobs"].eq(96).all() or not reg["sample_start"].eq("2015-01").all() or not reg["sample_end"].eq("2022-12").all() or not reg["frequency"].eq("monthly").all():
    raise ValueError("Regression output violates the frozen monthly estimation window")
oos = pd.read_csv(OUT/"T21_oos_alpha_check.csv")
if not {"t_stat_hac", "t_stat_method"}.issubset(oos.columns) or not oos["t_stat_method"].eq("HAC, 3 lags").all():
    raise ValueError("Out-of-sample alpha inference must report unannualized HAC t-statistics")
backtest = pd.read_csv(OUT/"T22_evaluation_2023_2025.csv", index_col=0)
if "rebalance_count" not in backtest.columns or backtest.loc["Recommended (frozen)", "rebalance_count"] != 1 or backtest.loc["Benchmark SPY", "rebalance_count"] != 0:
    raise ValueError("Evaluation output does not reflect the December-only 5pp drift-trigger rule")
if not np.isclose(sum(frozen["growth_weights"].values()), 1.0, atol=1e-5):
    raise ValueError("Frozen initial growth allocation does not sum to one")
print("Final audit validations passed: provenance, frozen monthly window, CAPM/FF3/FF5, HAC evaluation, rebalance trigger, and unchanged allocation.")


# The final message and `frozen_policy.json` show which internal checks passed. Passing does not establish full assignment compliance or mean the team has approved the policy.

# ## 9. Revised mandate (trustee message of 23 October)
# 
# The trustees asked us to assess a different payment schedule as if it had applied on 31 December 2022. The learning-centre payment is split into USD 1.2 million on 31 December 2025 and USD 2.4 million on 31 December 2027. The scholarship payment (USD 2.4 million in 2024), the USD 12 million budget and the 2030 purchasing-power goal stay the same. Total nominal commitments are still USD 6.0 million.
# 
# We change one thing: the payment schedule fed into the funding step. The decision date, bond quotes, information cutoff, estimation window, assumptions and growth-sleeve weights are all unchanged. Any difference in the results is therefore caused by the mandate, not by a new method. Section 11 adds diagnostics but does not change any holding.

# ## Funding the revised commitments
# 
# This cell reuses the 22 October funding method: the cheapest non-negative bond portfolio whose cumulative cash covers cumulative payments, rounded up to whole bonds, with surplus cash earning 0%. It first reruns the method on the original schedule and stops if the frozen holdings (2,172 Beta, 3,258 Delta) are not reproduced. It then solves the revised schedule. Results are saved in `T27_revised_funding_cashflows.csv` and `T28_revised_bond_holdings.csv`.
# 
# It then reprices assets and liabilities for both mandates under the same parallel and curve-shape shocks as `T08` (`T29_rate_scenarios_both_mandates.csv`) and plots both cash-flow schedules in `F03_funding_both_mandates.png`. The 2025 payment now falls on Gamma's maturity date, so the method buys Gamma, which it did not use before.

# In[14]:


# ---- revised mandate (23 Oct): same decision date, same bond quotes, same funding method as T06/T07 ----
PAY_ORIG = dict(P["PAY"])
PAY_REV = {2: 2_400_000, 3: 1_200_000, 5: 2_400_000}       # year -> USD (2024, 2025, 2027)
if sum(PAY_REV.values()) != sum(PAY_ORIG.values()):
    raise ValueError("Revised schedule should keep total nominal commitments at USD 6.0 million")

def fund_plan(pay_dict):
    """Cheapest whole-unit bond portfolio whose cumulative cash covers cumulative payments (0% cash carry)."""
    pay_ = np.zeros(H)
    for yr, a in pay_dict.items(): pay_[yr-1] = a
    r_ = linprog(c=bonds.loc[names, "price"].values, A_ub=-(cum@cfm.T), b_ub=-(cum@pay_), bounds=[(0, None)]*len(names), method="highs")
    if not r_.success:
        raise RuntimeError(f"Bond cash-flow funding optimization failed: {r_.message}")
    u_ = np.ceil(r_.x - 1e-9) + 0.0                      # whole bonds; +0.0 avoids printing -0.0
    inflow_ = cfm.T@u_; bal_ = np.cumsum(inflow_ - pay_)
    if bal_.min() < -1e-6:
        raise RuntimeError("Rounded bond holdings do not cover every payment")
    return dict(pay=pay_, units=u_, cost=float((u_*bonds.loc[names, "price"].values).sum()), inflow=inflow_, bal=bal_)

plan_o = fund_plan(PAY_ORIG)
if not np.allclose(plan_o["units"], units):
    raise ValueError("Re-running the original funding method must reproduce the frozen 22 Oct bond holdings")
plan_r = fund_plan(PAY_REV)

fund_rev = pd.DataFrame({"bond_cash_in": plan_r["inflow"], "payment": plan_r["pay"], "closing_cash_0pct": plan_r["bal"]}, index=range(2023, 2028))
save_table(fund_rev, "T27_revised_funding_cashflows")
hold_rev = pd.DataFrame({"units_original": plan_o["units"], "units_revised": plan_r["units"], "price": bonds.loc[names, "price"].values}, index=names)
hold_rev["cost_original"] = hold_rev.units_original*hold_rev.price; hold_rev["cost_revised"] = hold_rev.units_revised*hold_rev.price
hold_rev["cost_change"] = hold_rev.cost_revised - hold_rev.cost_original
save_table(hold_rev, "T28_revised_bond_holdings")

# exact repricing of assets and liabilities on the bootstrapped curve for both mandates
def asset_pv_u(u_, sh): return sum(u_[i]*(lambda tc: (tc[1]/(1+curve(tc[0])+sh(tc[0]))**tc[0]).sum())(cfs(bonds.loc[n])) for i, n in enumerate(names))
def liab_pv_p(pay_, sh): return sum(pay_[k]/(1+curve(k+1)+sh(k+1))**(k+1) for k in range(H) if pay_[k] > 0)
def mac_dur_pay(pay_):
    tt_ = np.array([k+1 for k in range(H) if pay_[k] > 0]); pv_ = np.array([pay_[k-1]/(1+curve(k))**k for k in tt_])
    return float((tt_*pv_).sum()/pv_.sum())
def mac_dur_units(u_):
    return sum(u_[i]*mac_pv(n)[0] for i, n in enumerate(names))/sum(u_[i]*mac_pv(n)[1] for i, n in enumerate(names))
rows = []
for k, sh in shifts.items():
    for lab, pl in [("original", plan_o), ("revised", plan_r)]:
        a, l = asset_pv_u(pl["units"], sh), liab_pv_p(pl["pay"], sh)
        rows.append(dict(mandate=lab, scenario=k, assets_pv=a, liabilities_pv=l, surplus=a-l, liability_pv_change=l/liab_pv_p(pl["pay"], shifts["base"])-1))
sc_rev = pd.DataFrame(rows).set_index(["mandate", "scenario"])
sc_rev["surplus_change"] = sc_rev.surplus - sc_rev.groupby(level=0).surplus.transform(lambda s: s.xs("base", level=1).iloc[0])
save_table(sc_rev, "T29_rate_scenarios_both_mandates")
print("Liability PV  original %.0f | revised %.0f" % (liab_pv_p(plan_o["pay"], shifts["base"]), liab_pv_p(plan_r["pay"], shifts["base"])))
print("Liability Macaulay duration  original %.2f | revised %.2f yrs" % (mac_dur_pay(plan_o["pay"]), mac_dur_pay(plan_r["pay"])))
print("Bond cost  original %.2f | revised %.2f | change %.2f" % (plan_o["cost"], plan_r["cost"], plan_r["cost"]-plan_o["cost"]))

fig, axs = plt.subplots(1, 2, figsize=(10, 3.4), sharey=True)
for ax, (lab, pl) in zip(axs, [("Original mandate (22 Oct)", plan_o), ("Revised mandate (23 Oct)", plan_r)]):
    x = np.arange(2023, 2028)
    ax.bar(x-0.2, pl["inflow"]/1e6, 0.4, label="Bond cash in"); ax.bar(x+0.2, pl["pay"]/1e6, 0.4, label="Payment")
    ax.set_title(lab); ax.set_xticks(x); ax.set_ylabel("USD million")
axs[0].legend(); save_fig("F03_funding_both_mandates")


# Review `T27` and `T28` for the payment-date cash balances and changes in bond units, and `T29` for repricing under the scenarios. Cash-flow matching means the payments do not depend on resale prices. The PV surplus in `T29` shows sensitivity to rates, not a funding gap.

# ## 10. Growth sleeve, goal, and dollar allocation under the revised mandate
# 
# This cell keeps the frozen growth weights and recalculates only what depends on sleeve size: the growth amount, residual cash, the return needed for the 2030 goal, the lognormal goal probability, real-value percentiles, the real goal reachable with 75% confidence, and the loss diagnostic on the total fund. `T30_mandate_comparison.csv` sets the two mandates side by side. `T31_revised_initial_allocation.csv` gives the full USD 12 million allocation and the dollar change for every line from the 22 October allocation.
# 
# The weights are not re-optimised. Mean-variance weights do not depend on how many dollars the sleeve holds. Re-optimising after seeing 2023-2025 returns would also bring hindsight into the decision (Lecture 8).

# In[15]:


# ---- consequences for the growth sleeve and the 2030 goal: growth weights kept frozen, only the sleeve size changes ----
def mandate_state(pl):
    G_ = P["FUND"] - pl["cost"] - P["CASH_BUFFER"]; tc_ = P["TC"]*G_
    other_ = P["CASH_BUFFER"] - tc_ + pl["bal"][-1]           # cash buffer net of costs + bond residual cash, 0% to 2030
    return dict(G=G_, tc=tc_, other=other_, share=G_/P["FUND"])
def req_ret_s(st, infl): return ((P["GOAL_REAL"]*(1+infl)**P["GOAL_YEARS"] - st["other"])/st["G"])**(1/P["GOAL_YEARS"]) - 1
def p_goal_s(st, mu_p, sig, infl):
    s2_ = np.log(1+sig**2/(1+mu_p)**2); mL_ = np.log(1+mu_p) - s2_/2; T_ = P["GOAL_YEARS"]
    need_ = P["GOAL_REAL"]*(1+infl)**T_ - st["other"]
    return 1 - norm.cdf((np.log(need_/st["G"]) - mL_*T_)/np.sqrt(s2_*T_))
def real_pct_s(st, mu_p, sig, p):
    s2_ = np.log(1+sig**2/(1+mu_p)**2); mL_ = np.log(1+mu_p) - s2_/2; T_ = P["GOAL_YEARS"]
    return (st["G"]*np.exp(mL_*T_ + norm.ppf(p)*np.sqrt(s2_*T_)) + st["other"])/(1+P["INFLATION"])**T_
def goal_at_conf(st, mu_p, sig, conf): return real_pct_s(st, mu_p, sig, 1-conf)   # real goal reachable with probability conf

st_o, st_r = mandate_state(plan_o), mandate_state(plan_r)
if not np.isclose(st_o["G"], G_total):
    raise ValueError("Original growth sleeve must reproduce the frozen 22 Oct amount")
mu_rec, sig_rec = float(w_rec@mu), float(np.sqrt(w_rec@S_si@w_rec))
worst12 = hist["worst_12m_sleeve"]
rows = {}
for lab, pl, st in [("original_22oct", plan_o, st_o), ("revised_mandate", plan_r, st_r)]:
    rows[lab] = {"bond_cost_usd": pl["cost"], "liability_pv_usd": liab_pv_p(pl["pay"], shifts["base"]),
                 "liability_macaulay_yrs": mac_dur_pay(pl["pay"]), "asset_macaulay_yrs": mac_dur_units(pl["units"]),
                 "min_payment_date_cash_usd": float(min(pl["bal"][k] for k in range(H) if pl["pay"][k] > 0)),
                 "residual_cash_2027_usd": pl["bal"][-1], "growth_sleeve_usd": st["G"], "growth_share_of_fund": st["share"],
                 "expected_growth_return": mu_rec, "required_growth_return_base": req_ret_s(st, P["INFLATION"]),
                 "goal_probability_base": p_goal_s(st, mu_rec, sig_rec, P["INFLATION"]),
                 "goal_probability_infl_4pct": p_goal_s(st, mu_rec, sig_rec, 0.04),
                 "real_value_P10": real_pct_s(st, mu_rec, sig_rec, 0.10), "real_value_P25": real_pct_s(st, mu_rec, sig_rec, 0.25),
                 "real_value_P50": real_pct_s(st, mu_rec, sig_rec, 0.50), "real_goal_at_75pct_conf": goal_at_conf(st, mu_rec, sig_rec, 0.75),
                 "model_loss95_total_fund": -(mu_rec-1.645*sig_rec)*st["share"], "worst_hist_12m_total_fund": worst12*st["share"],
                 "inflation_threshold": brentq(lambda i: req_ret_s(st, i) - mu_rec, 0.0, 0.25)}
mcmp = pd.DataFrame(rows); mcmp["change"] = mcmp.revised_mandate - mcmp.original_22oct
save_table(mcmp, "T30_mandate_comparison")

alloc_rev = pd.concat([pd.Series(plan_r["units"]*bonds.loc[names, "price"].values, index=names, name="usd"), (w_rec*st_r["G"]).rename("usd")])
alloc_rev.loc["Cash buffer"] = P["CASH_BUFFER"] - st_r["tc"]; alloc_rev.loc["Trading costs (growth buy)"] = st_r["tc"]
alloc_rev = alloc_rev.to_frame("usd_revised"); alloc_rev["pct_of_fund"] = alloc_rev.usd_revised/P["FUND"]
alloc_rev["usd_original"] = alloc["usd"].reindex(alloc_rev.index); alloc_rev["usd_change"] = alloc_rev.usd_revised - alloc_rev.usd_original
assert abs(alloc_rev.usd_revised.sum() - P["FUND"]) < 1, alloc_rev.usd_revised.sum()
save_table(alloc_rev, "T31_revised_initial_allocation")


# Use `T30` to quantify the consequences of the mandate and `T31` to check that the revised allocation sums to USD 12 million. The goal probability and percentiles rest on the same planning assumptions as `T23`/`T24`, so they are scenarios, not forecasts.

# ## 11. Evidence that tests the recommendation
# 
# The four cells below were added for the final submission. They report results but change no holding.
# 
# 1. **Funding alternative (Lecture 3).** Immunization matches the duration of the liabilities instead of their cash flows. We build two duration-matched portfolios and reprice them under the same shocks.
# 2. **Measuring the 15% loss concern (Lecture 4).** We report normal VaR, historical VaR and ES from rolling 12-month returns, the worst 12-month loss, maximum drawdown, the 2022 calendar-year loss, and the skewness and kurtosis of monthly returns. Each is shown for the sleeve and for the total fund.
# 3. **Risk-return preference (Lectures 4-5).** We compare the certainty-equivalent return U = E(r) - 0.5*A*var of each candidate and solve for the risk aversion at which a simple 100% SPY sleeve would replace our portfolio.
# 4. **Risk-adjusted evaluation (Lectures 6-8).** We report the CAPM alpha (index-model intercept) against SPY over 2023-2025, plus a beta-matched SPY + T-bill comparator built only from pre-2023 data.

# ## Immunization versus cash-flow dedication
# 
# For the revised liabilities, this cell builds two duration-matched portfolios. The first is a barbell of Beta and Epsilon. The second pairs Alpha with Delta. Each costs exactly the liabilities' present value on the bootstrapped curve. We then compare their surplus under the `T08` shocks with the dedicated portfolio's. Results are in `T32_immunization_vs_dedication.csv`.
# 
# Under parallel shifts, immunization performs as the lecture predicts: the surplus stays close to zero and convexity makes it slightly positive. Under the curve-shape shocks it carries far more risk than dedication. It would also require rebalancing, coupon reinvestment and, for Epsilon, a sale in 2027 at a price the case does not provide.

# In[16]:


# ---- rejected funding alternative (Lecture 3): duration-matched immunization instead of cash-flow dedication ----
def bond_pv_dur(n):
    t_, c_ = cfs(bonds.loc[n]); pv_ = c_/(1+curve(t_))**t_; return pv_.sum(), (t_*pv_).sum()/pv_.sum()
L0, DL = liab_pv_p(plan_r["pay"], shifts["base"]), mac_dur_pay(plan_r["pay"])
rows = []
for short, long_ in [("Beta", "Epsilon"), ("Alpha", "Delta")]:
    (p_s, d_s), (p_l, d_l) = bond_pv_dur(short), bond_pv_dur(long_)
    w_long = (DL - d_s)/(d_l - d_s)                                   # w_s*D_s + w_l*D_l = D_L, weights sum to one
    u_imm = {short: (1-w_long)*L0/p_s, long_: w_long*L0/p_l}
    def imm_pv(sh):
        return sum(u*(lambda tc: (tc[1]/(1+curve(tc[0])+sh(tc[0]))**tc[0]).sum())(cfs(bonds.loc[n])) for n, u in u_imm.items())
    for k, sh in shifts.items():
        rows.append(dict(strategy=f"Immunize {short}+{long_}", scenario=k, w_long=w_long, cost_usd=L0,
                         surplus=imm_pv(sh) - liab_pv_p(plan_r["pay"], sh),
                         needs_resale_or_rebalancing="yes" if long_ == "Epsilon" else "rebalancing; coupons reinvested"))
for k, sh in shifts.items():
    rows.append(dict(strategy="Dedication (recommended)", scenario=k, w_long=np.nan, cost_usd=plan_r["cost"],
                     surplus=asset_pv_u(plan_r["units"], sh) - liab_pv_p(plan_r["pay"], sh), needs_resale_or_rebalancing="no"))
imm = pd.DataFrame(rows).set_index(["strategy", "scenario"])
save_table(imm, "T32_immunization_vs_dedication")
print("Revised liabilities: PV %.0f, Macaulay duration %.2f yrs; dedication costs %.0f more than PV (whole units, 0%% carry)" % (L0, DL, plan_r["cost"]-L0))


# In `T32`, compare the surplus range across scenarios. The dedicated portfolio costs a few thousand dollars more than the liability PV because of whole-unit rounding and 0% cash carry. That is the price of removing the twist exposure and the resale assumption.

# ## How large is the loss the trustees are worried about?
# 
# The trustees did not say how "losses approaching 15%" should be measured. This cell computes the frozen sleeve's losses under several definitions using only 2015-2022 data and saves them in `T33_loss_measures.csv`. It shows each measure for the sleeve and for the total fund under the revised mandate, and does the same for a sleeve held entirely in SPY. It also reports the skewness and excess kurtosis of monthly returns. Lecture 4 warns that negative skew and fat tails make normal-based VaR too optimistic.

# In[17]:


# ---- how the 15% loss concern looks under different measures (Lecture 4: VaR, ES, skewness, kurtosis) ----
def loss_profile(r_m, mu_a, sig_a):
    r12 = (1+r_m).rolling(12).apply(np.prod, raw=True).dropna() - 1; q5 = r12.quantile(0.05); wl = (1+r_m).cumprod()
    return {"normal_VaR95_1y": -(mu_a - 1.645*sig_a), "hist_VaR95_rolling12m": -q5, "hist_ES95_rolling12m": -r12[r12 <= q5].mean(),
            "worst_12m_loss": -r12.min(), "max_drawdown": -(wl/wl.cummax()-1).min(),
            "calendar_2022_loss": -((1+r_m.loc["2022-01":"2022-12"]).prod()-1),
            "monthly_skewness": r_m.skew(), "monthly_excess_kurtosis": r_m.kurt()}
spy_mu, spy_sig = float(mu["SPY"]), float(np.sqrt(S_si.loc["SPY", "SPY"]))
lp = pd.DataFrame({"sleeve_recommended": loss_profile(Rw@w_rec, mu_rec, sig_rec), "sleeve_if_100pct_SPY": loss_profile(Rw["SPY"], spy_mu, spy_sig)})
for c in ["sleeve_recommended", "sleeve_if_100pct_SPY"]:
    lp[c.replace("sleeve", "total_fund_revised")] = lp[c]*st_r["share"]
lp.loc[["monthly_skewness", "monthly_excess_kurtosis"], ["total_fund_revised_recommended", "total_fund_revised_if_100pct_SPY"]] = np.nan
lp["sleeve_rec_exceeds_15pct"] = ["" if i.startswith("monthly") else ("yes" if v > P["LOSS_LIMIT"] else "no") for i, v in lp["sleeve_recommended"].items()]
save_table(lp, "T33_loss_measures")
# share of the growth sleeve that could stay in equities before the historical sleeve drawdown reaches 15% (rest in 0% cash)
dd_scale = P["LOSS_LIMIT"]/lp.loc["max_drawdown", "sleeve_recommended"]
print("Recommended sleeve max drawdown %.1f%%: keeping it below 15%% would need about %.0f%% of the sleeve in equities" % (lp.loc["max_drawdown","sleeve_recommended"]*100, min(dd_scale, 1)*100))


# `T33` shows that the 15% concern binds only under one reading: peak-to-trough drawdown measured on the growth sleeve alone. On the total fund, every measure stays well below 15%. A 100% SPY sleeve still stays below 15% at total-fund level, but its sleeve drawdown would be about 24%.

# ## Risk-return preference and the risk-aversion threshold
# 
# This cell compares candidate growth sleeves under the same inputs: CAPM expected returns, the single-index risk model, and the revised-mandate goal and loss figures. It reports U = E(r) - 0.5*A*var for several values of A and solves for A*, the risk aversion at which a trustee would be indifferent between each candidate and our sleeve. Results are in `T34_utility_comparison.csv` and `F04_utility_vs_risk_aversion.png`.
# 
# The simple 100% SPY sleeve is the comparator that matters. With A below A*, the trustees would prefer it. This is the assumption change that reverses an important decision.

# In[18]:


# ---- risk-return preference comparison and the risk-aversion threshold that reverses the growth decision (Lecture 4/5) ----
cands = {"Recommended (SI, A=4)": w_rec, "Sample-cov MV (A=4)": w_sa, "Rejected: Eta max-Sharpe": w_alt,
         "Simple: 100% SPY": pd.Series(1.0, index=["SPY"]).reindex(ASSETS).fillna(0), "Simple: 100% USMV": pd.Series(1.0, index=["USMV"]).reindex(ASSETS).fillna(0)}
rows = []
for k, w in cands.items():
    m_, s_ = float(w@mu), float(np.sqrt(w@S_si@w))
    rows.append(dict(candidate=k, exp_return=m_, vol_single_index=s_, vol_sample=float(np.sqrt(w@S_sa@w)), beta=float(w@beta),
                     **{f"U_A={a}": m_ - 0.5*a*s_**2 for a in [1, 2, 4, 6, 8]},
                     loss95_total_fund_revised=-(m_-1.645*s_)*st_r["share"], goal_prob_revised=p_goal_s(st_r, m_, s_, P["INFLATION"])))
ut = pd.DataFrame(rows).set_index("candidate")
def a_star(w1, w2, S):
    m1, m2 = float(w1@mu), float(w2@mu); v1, v2 = float(w1@S@w1), float(w2@S@w2); return 2*(m1-m2)/(v1-v2)
ut["A_indifferent_vs_recommended_SI"] = [np.nan if k.startswith("Recommended") else a_star(w, w_rec, S_si) for k, w in cands.items()]
ut["A_indifferent_vs_recommended_sample"] = [np.nan if k.startswith("Recommended") else a_star(w, w_rec, S_sa) for k, w in cands.items()]
save_table(ut, "T34_utility_comparison")
A_spy = ut.loc["Simple: 100% SPY", "A_indifferent_vs_recommended_SI"]
print("Trustees with risk aversion below A* = %.2f would prefer 100%% SPY to the recommended sleeve (CAPM returns, single-index risk)" % A_spy)
Agrid = np.linspace(0.5, 12, 100)
plt.figure(figsize=(8, 3.6))
for k, w in cands.items():
    m_, s_ = float(w@mu), float(np.sqrt(w@S_si@w)); plt.plot(Agrid, m_ - 0.5*Agrid*s_**2, label=k)
plt.axvline(P["RISK_AVERSION"], ls="--", c="grey"); plt.axvline(A_spy, ls=":", c="k")
plt.xlabel("Risk aversion A"); plt.ylabel("U = E(r) - 0.5 A var"); plt.title("Certainty-equivalent return by candidate"); plt.legend(fontsize=7)
save_fig("F04_utility_vs_risk_aversion")


# Read `T34` together with `T33`. Moving from our sleeve to 100% SPY raises expected return by about 1.5 points but barely changes the probability of reaching the goal, because the higher volatility offsets most of the gain. It also raises the model 95% loss on the total fund and the sleeve drawdown.

# ## Risk-adjusted view of 2023-2025
# 
# The frozen sleeve trailed SPY by a wide margin over 2023-2025. Using the same HAC (three-lag) regression as `T21`, this cell estimates realised beta and the CAPM alpha (regression intercept) against SPY. It also builds a beta-matched comparator, beta x SPY + (1 - beta) x T-bill, with beta estimated from 2015-2022 only. That comparator separates the effect of holding less market risk from the effect of security selection. Results are in `T35_risk_adjusted_evaluation.csv` and `F05_evaluation_beta_matched.png`. `T36_retrospective_sleeve_value_2025.csv` gives the sleeve's dollar value at the end of 2025 under each mandate.
# 
# These results are retrospective. They did not enter any decision, and three years cannot show whether the 2030 goal will be met.

# In[19]:


# ---- risk-adjusted view of 2023-2025: CAPM alpha against SPY and an ex-ante beta-matched SPY comparator ----
spy_ex_w = Rw["SPY"] - Fw["RF"]
beta_vs_spy = {k: float(((Rw@w.reindex(ASSETS).fillna(0))-Fw["RF"]).cov(spy_ex_w)/spy_ex_w.var()) for k, w in strats.items()}   # 2015-2022 only (ex ante)
rf_e = fac.loc[E0:E1, "RF"]; spy_e = rets["Benchmark SPY"]
bm = beta_vs_spy["Recommended (frozen)"]*spy_e + (1-beta_vs_spy["Recommended (frozen)"])*rf_e     # investable: SPY + T-bills
rows = []   # SPY and the beta-matched comparator fit exactly (zero residuals), so their alpha t-statistic is left blank
for k, r in {**rets, "Beta-matched SPY + T-bill": bm}.items():
    y = r - rf_e; x = sm.add_constant((spy_e - rf_e).rename("SPY_ex"))
    fit = sm.OLS(y, x).fit(cov_type="HAC", cov_kwds={"maxlags": 3})
    rows.append(dict(strategy=k, ex_ante_beta_vs_SPY=beta_vs_spy.get(k, np.nan), realized_beta_vs_SPY=fit.params["SPY_ex"],
                     alpha_ann_vs_SPY=fit.params["const"]*12, alpha_t_hac=fit.tvalues["const"] if fit.resid.std() > 1e-10 else np.nan, **perf(r, rf_e)))
ra = pd.DataFrame(rows).set_index("strategy")
save_table(ra, "T35_risk_adjusted_evaluation")
gap_total = ra.loc["Benchmark SPY", "cumulative"] - ra.loc["Recommended (frozen)", "cumulative"]
gap_beta = ra.loc["Benchmark SPY", "cumulative"] - ra.loc["Beta-matched SPY + T-bill", "cumulative"]
print("Cumulative gap to SPY %.1f pp, of which %.1f pp is explained by holding a lower-beta sleeve (beta-matched comparator)" % (gap_total*100, gap_beta*100))
pd.DataFrame({k: (1+r).cumprod() for k, r in {"Recommended (frozen)": rets["Recommended (frozen)"], "Benchmark SPY": spy_e, "Beta-matched SPY + T-bill": bm}.items()}
             ).set_index(Re.index.to_timestamp()).plot(figsize=(9, 3.6), title="Value of $1, 2023-2025: frozen sleeve vs SPY and beta-matched SPY")
save_fig("F05_evaluation_beta_matched")
# realized dollar path of the growth sleeve under each mandate (retrospective only; not used in any decision)
cum_rec = (1+rets["Recommended (frozen)"]).prod()
sleeve_2025 = pd.DataFrame({"growth_sleeve_start_usd": [st_o["G"], st_r["G"]], "growth_sleeve_end2025_usd": [st_o["G"]*cum_rec, st_r["G"]*cum_rec],
                            "payments_met_by_end2025_usd": [plan_o["pay"][:3].sum(), plan_r["pay"][:3].sum()],
                            "bond_cash_shortfall_by_end2025": [float(min(0, plan_o["bal"][:3].min())), float(min(0, plan_r["bal"][:3].min()))]},
                           index=["original_22oct", "revised_mandate"])
save_table(sleeve_2025, "T36_retrospective_sleeve_value_2025")


# In `T35`, lower beta explains only part of the gap to SPY. The rest is negative selection relative to a beta-matched SPY holding, mainly from underweighting the large technology stocks that led 2023-2025. The alpha is not statistically significant, so it shows neither skill nor its absence. We report it as inconvenient evidence and do not change the weights in response, because that would chase past returns.

# ## 12. What changed and the final policy snapshot
# 
# This cell records, item by item, what differs between the 22 October policy and the final revised-mandate policy, and why (`T37_change_attribution.csv`). It writes `final_policy_revised.json` and stops if the growth weights differ from the frozen 22 October snapshot or if the original bond units are not reproduced.

# In[20]:


# ---- what changed, and why: mandate-driven changes vs method/assumption changes ----
fmt_u = lambda pl: ", ".join(f"{n} {int(u):,}" for n, u in zip(names, pl["units"]) if u > 0)
attr = pd.DataFrame([
    ("Bond holdings (units)", fmt_u(plan_o), fmt_u(plan_r), "Revised mandate", "Same LP dedication method; the new 2025 payment brings Gamma in"),
    ("Bond cost (USD)", f"{plan_o['cost']:,.2f}", f"{plan_r['cost']:,.2f}", "Revised mandate", "USD 1.2m moves from 2027 to 2025, so it is discounted for fewer years"),
    ("Growth sleeve (USD)", f"{st_o['G']:,.2f}", f"{st_r['G']:,.2f}", "Revised mandate", "Residual after bonds and the unchanged USD 250k buffer"),
    ("Growth weights", "frozen 22 Oct weights", "unchanged", "No change", "Optimizer inputs do not depend on the sleeve size; no re-optimisation on 2023-2025 data"),
    ("Goal probability (base)", f"{mcmp.loc['goal_probability_base','original_22oct']:.1%}", f"{mcmp.loc['goal_probability_base','revised_mandate']:.1%}", "Revised mandate", "Smaller sleeve and different residual cash"),
    ("Model 95% one-year loss, total fund", f"{mcmp.loc['model_loss95_total_fund','original_22oct']:.2%}", f"{mcmp.loc['model_loss95_total_fund','revised_mandate']:.2%}", "Revised mandate", "Growth share of fund changes; sleeve risk unchanged"),
    ("Assumptions (inflation, ERP, A, cap, TC, 0% carry)", "2.5%, 5%, 4, 25%, 10bp, 0%", "unchanged", "No change", "Kept fixed so the mandate effect is isolated"),
    ("Benchmark, windows, rebalancing rule", "SPY; 2015-22 / 2023-25; Dec, 5pp", "unchanged", "No change", "Frozen evaluation rule"),
    ("Added diagnostics (T32-T36)", "not reported", "reported", "Method addition (reporting only)", "Immunization comparison, loss measures, utility threshold, beta-matched comparator; no effect on holdings"),
    ("Raw-file path handling", "Windows separators only", "portable paths", "Reproducibility fix", "No effect on numbers; raw-file hashes unchanged"),
], columns=["item", "original_22oct", "final_revised", "cause", "explanation"]).set_index("item")
save_table(attr, "T37_change_attribution")

final_policy = {"mandate": "revised (23 Oct 2026 trustee message), assessed at 31 Dec 2022",
                "payments": {str(2022+k): v for k, v in PAY_REV.items()},
                "bond_units": dict(zip(names, plan_r["units"].tolist())), "bond_cost_usd": round(plan_r["cost"], 2),
                "growth_weights": w_rec.round(6).to_dict(), "growth_usd": round(st_r["G"], 2),
                "cash_buffer_net": round(P["CASH_BUFFER"] - st_r["tc"], 2), "initial_trading_cost": round(st_r["tc"], 2),
                "rebalance_rule": "each December to frozen weights; trade if drift > 5pp", "benchmark": P["BENCH"],
                "assumptions": {k: P[k] for k in ["INFLATION", "ERP", "RISK_AVERSION", "LOSS_LIMIT", "CASH_BUFFER", "MAX_W", "TC"]},
                "estimation_window": list(P["WIN"]), "evaluation_window": list(P["EVAL"]),
                "compared_with": "outputs/original/frozen_policy.json"}
orig_policy = json.loads((ROOT/"outputs"/"original"/"frozen_policy.json").read_text(encoding="utf-8"))
if any(abs(orig_policy["growth_weights"][t] - final_policy["growth_weights"][t]) > 1e-6 for t in ASSETS):
    raise ValueError("Final growth weights differ from the frozen 22 Oct policy; record the change before proceeding")
if any(orig_policy["bond_units"][n] != plan_o["units"][i] for i, n in enumerate(names)):
    raise ValueError("Original bond units are not reproduced")
(OUT/"final_policy_revised.json").write_text(json.dumps(final_policy, indent=2, default=float), encoding="utf-8")
print("Final policy written; growth weights identical to the 22 Oct frozen policy; bond units changed only because of the mandate.")


# `final_policy_revised.json` is the policy we ask the trustees to authorize under the revised mandate. `T37` shows that every numerical change follows from the new payment schedule. The new diagnostics and the path fix change no holding.
