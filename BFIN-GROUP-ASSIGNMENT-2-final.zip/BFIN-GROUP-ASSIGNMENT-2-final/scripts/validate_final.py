"""Check the final (29 October) outputs against the frozen 22 October policy.

Run from the repository root after the final notebook or scripts/analysis_final.py:
    python scripts/validate_final.py
The script only reads files. It makes no network requests.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "final_2026-10-29"
ORIG = ROOT / "outputs" / "original"
FUND = 12_000_000
PAY_REVISED = {2024: 2_400_000, 2025: 1_200_000, 2027: 2_400_000}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)
    print("PASS:", message)


def table(name: str) -> pd.DataFrame:
    hits = sorted(FINAL.glob(f"{name}_*.csv"))
    require(len(hits) == 1, f"{name} exists in outputs/final_2026-10-29/")
    return pd.read_csv(hits[0], index_col=0)


frozen = json.loads((ORIG / "frozen_policy.json").read_text(encoding="utf-8"))
final = json.loads((FINAL / "final_policy_revised.json").read_text(encoding="utf-8"))

# 1. Growth weights and assumptions are the frozen 22 October ones.
w0, w1 = pd.Series(frozen["growth_weights"]), pd.Series(final["growth_weights"])
require(w0.index.equals(w1.index) and np.allclose(w0, w1, atol=1e-9), "growth weights equal the 22 Oct frozen weights")
require(abs(w1.sum() - 1) < 1e-6 and w1.min() >= 0 and w1.max() <= 0.25 + 1e-9, "weights sum to 1, long-only, cap 25%")
for k, v in final["assumptions"].items():
    require(frozen["params"][k] == v, f"assumption {k} unchanged ({v})")
require(final["benchmark"] == frozen["benchmark"] and final["rebalance_rule"] == frozen["rebalance_rule"],
        "benchmark and rebalancing rule unchanged")
require(final["estimation_window"] == frozen["estimation_window"] and final["evaluation_window"] == frozen["evaluation_window"],
        "estimation and evaluation windows unchanged")

# 2. Revised payments are funded every year with non-negative cash.
require({int(k): v for k, v in final["payments"].items()} == PAY_REVISED, "payments are the 23 Oct revised schedule")
cf = table("T27")
require((cf["closing_cash_0pct"] >= -1e-6).all(), "revised bond cash flows meet every payment (no negative cash)")
for year, amount in PAY_REVISED.items():
    require(abs(cf.loc[year, "payment"] - amount) < 1e-6, f"T27 payment {year} = {amount:,.0f}")

# 3. Bond holdings, cost and the 12m budget.
h = table("T28")
units = pd.Series(final["bond_units"])
require(np.allclose(h["units_revised"].reindex(units.index), units), "T28 units match final_policy_revised.json")
require(np.allclose(h["units_original"].reindex(units.index), pd.Series(frozen["bond_units"]).abs()), "T28 original units match frozen policy")
cost = float((h["units_revised"] * h["price"]).sum())
require(abs(cost - final["bond_cost_usd"]) < 0.01, "bond cost = units x prices")
total = final["bond_cost_usd"] + final["growth_usd"] + final["cash_buffer_net"] + final["initial_trading_cost"]
require(abs(total - FUND) < 0.01, f"bonds + growth + buffer + trading cost = USD {FUND:,.0f}")
alloc = table("T31")
require(abs(alloc["usd_revised"].sum() - FUND) < 0.01, "T31 revised allocation sums to USD 12m")

# 4. Mandate comparison is consistent with the original baseline.
cmp = table("T30")
require(abs(cmp.loc["bond_cost_usd", "original_22oct"] - 5_216_894.22) < 0.01, "T30 original bond cost equals 22 Oct baseline")
require(abs(cmp.loc["growth_sleeve_usd", "revised_mandate"] - final["growth_usd"]) < 0.01, "T30 revised sleeve equals policy file")
require(cmp.loc["expected_growth_return", "change"] == 0, "expected growth return unchanged (weights unchanged)")

# 5. Diagnostics exist and attribution records every change.
for name in ["T29", "T32", "T33", "T34", "T35", "T36"]:
    require(len(table(name)) > 0, f"{name} is non-empty")
att = pd.read_csv(sorted(FINAL.glob("T37_*.csv"))[0])
require({"Revised mandate", "No change"}.issubset(set(att["cause"])), "T37 attributes changes to the mandate or marks them unchanged")
for fig in ["F01", "F02", "F03", "F04", "F05"]:
    require(len(list(FINAL.glob(f"{fig}_*.png"))) == 1, f"figure {fig} exists")

# 6. The frozen baseline was reproduced: T00-T26 equal outputs/original (T02 equals the 22 Oct eligibility review).
# Numbers are compared with a 1e-6 tolerance: optimizer output can differ in the last digits across platforms.
review = ROOT / "outputs" / "eligibility_review_2026-10-22"
for f in sorted(ORIG.glob("T*.csv")):
    ref = review / f.name if f.name.startswith("T02") else f
    a, b = pd.read_csv(ref), pd.read_csv(FINAL / f.name)
    same = a.shape == b.shape and list(a.columns) == list(b.columns)
    if same:
        num = a.select_dtypes("number").columns
        same = np.allclose(a[num], b[num], rtol=1e-6, atol=1e-6, equal_nan=True) and a.drop(columns=num).equals(b.drop(columns=num))
    require(same, f"{f.name} reproduces the 22 Oct baseline")

print("All final-submission checks passed.")
