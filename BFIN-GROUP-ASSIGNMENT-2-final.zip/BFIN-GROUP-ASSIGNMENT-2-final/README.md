# Kappa Foundation — BFIN WS2026 Group Assignment

Investment-policy analysis for the Kappa Foundation case (decision date 31 December 2022). This archive is our **final submission of 29 October 2026**. It keeps the 22 October submission unchanged and adds the response to the trustees' revised mandate of 23 October.

## Where to start

| Deliverable | File |
|---|---|
| Committee memo (7 pages incl. references) | [`Bài nộp cho 2910/Committee_Memo_2026-10-29.pdf`](<Bài nộp cho 2910/Committee_Memo_2026-10-29.pdf>) (editable: `.docx`) |
| Slide deck | [`Bài nộp cho 2910/Committee_Presentation_2026-10-29.pdf`](<Bài nộp cho 2910/Committee_Presentation_2026-10-29.pdf>) (editable: `.pptx`) |
| Executed final notebook | [`Bài nộp cho 2910/analysis_final.ipynb`](<Bài nộp cho 2910/analysis_final.ipynb>); script export `scripts/analysis_final.py` |
| Rebuild instructions | [`Bài nộp cho 2910/HOW_TO_REBUILD.md`](<Bài nộp cho 2910/HOW_TO_REBUILD.md>) |
| Decision log (final) | [`Bài nộp cho 2910/Decision_Log_2026-10-29.md`](<Bài nộp cho 2910/Decision_Log_2026-10-29.md>), continuing [`docs/decisions/Decision_Log_2026-10-22.md`](docs/decisions/Decision_Log_2026-10-22.md) |
| Data record | [`Bài nộp cho 2210/Dated_Data_Record_2026-10-22.md`](<Bài nộp cho 2210/Dated_Data_Record_2026-10-22.md>) + [addendum](<Bài nộp cho 2910/Data_Record_Addendum_2026-10-29.md>) |
| Contribution statement and critiques | [`Bài nộp cho 2910/Contribution_Statement_and_Critiques.md`](<Bài nộp cho 2910/Contribution_Statement_and_Critiques.md>) |
| AI-use disclosure | [`Bài nộp cho 2910/AI_Use_Disclosure.md`](<Bài nộp cho 2910/AI_Use_Disclosure.md>) |
| 22 October submission (unchanged) | [`Bài nộp cho 2210/`](<Bài nộp cho 2210/>): initial decision record (PDF), dated data record, `analysis.ipynb` |

## Final recommendation in brief

Buy 2,157 Beta, 1,079 Gamma and 2,243 Delta bonds (USD 5,283,878) and hold them to maturity to fund USD 2.4m (2024), USD 1.2m (2025) and USD 2.4m (2027). Invest USD 6,466,122 in the growth sleeve frozen on 22 October (SPY 25%, USMV 25%, PG 15.5%, JNJ 15.3%, NEE 10.7%, UNH 6.0%, HD 1.8%, MSFT 0.7%), rebalanced each December if a weight drifts by more than 5 pp, with SPY as benchmark. Keep a USD 250k buffer (net of trading costs). See `outputs/final_2026-10-29/final_policy_revised.json` and `T37_change_attribution.csv` for what changed relative to 22 October and why.

## Repository layout

```text
.
├── Bài nộp cho 2210/        # 22 Oct submission (frozen): decision record PDF, data record, analysis.ipynb
├── Bài nộp cho 2910/        # Final submission: memo, slides, final notebook, logs, statements
│   └── document_sources/    # build_memo.py (rebuilds the memo DOCX from the output tables)
├── data/
│   ├── raw/                 # Yahoo (yfinance) and Kenneth French downloads + source_record.json (hashes)
│   ├── processed/           # Monthly returns and factors built from raw
│   └── *.csv, *.md          # Source record, eligibility evidence, data dictionary
├── docs/                    # Assignment brief, data audit, 22 Oct decision record and log
├── notebooks/               # Audited and explained copies of the 22 Oct notebook
├── outputs/
│   ├── original/            # Frozen 22 Oct baseline (never overwritten)
│   ├── eligibility_review_2026-10-22/
│   └── final_2026-10-29/    # Final tables T00-T37, figures F01-F05, final_policy_revised.json
├── scripts/                 # analysis.py (22 Oct), analysis_final.py (final), validators
├── src/download_data.py     # Retrieval code (internet; refuses to overwrite the snapshot)
├── config.json
├── requirements.txt
└── requirements-lock.txt    # Pinned environment (Python 3.13)
```

## Requirement checklist

| Requirement | Where it is met |
|---|---|
| Full USD 12m allocation, funded payments, risk tolerance and real goal, utility comparison | Memo §1-3, `T09`, `T10`, `T31`, `T34`, `F04` |
| Bond valuation, incomplete curve, duration/convexity vs exact repricing, parallel and curve-shape scenarios | Memo §4, `T03`-`T08`, `T27`-`T29`, `T32`, `F03` |
| One recommended and one rejected allocation; sample vs single-index covariance; inputs, constraints, sensitivity | Memo §5, `T11`-`T17`, `T13`, `F01` |
| Market-only vs multifactor models for the sleeve and two securities; what alpha does and does not show | Memo §6, `T18`-`T21` |
| Frozen strategy vs frozen benchmark 2023-2025; reversal threshold; inconvenient results | Memo §7-8, `T22`, `T26`, `T33`-`T35`, `F02`, `F05` |
| Response to the revised mandate, separated from method changes | Memo §2, `T30`, `T31`, `T37`, decision log |
| Reproducibility from raw data, offline | `HOW_TO_REBUILD.md`, `scripts/validate_data.py`, `validate_analysis.py`, `validate_final.py` |
| Contribution statement, critiques, AI disclosure | `Bài nộp cho 2910/` (team to fill in names and own critiques) |

## Quick rebuild

```bash
python -m pip install -r requirements-lock.txt
python scripts/validate_data.py
MPLBACKEND=Agg python scripts/analysis_final.py      # PowerShell: $env:MPLBACKEND="Agg"; python scripts\analysis_final.py
python scripts/validate_analysis.py --tag final_2026-10-29
python scripts/validate_final.py
```

Full instructions, including the notebook route, are in `Bài nộp cho 2910/HOW_TO_REBUILD.md`.

## Data handling

- Do not edit or re-save the raw files in `data/raw/`. Their identifiers, settings, coverage and SHA-256 hashes are in `data/raw/source_record.json`. The Yahoo CSVs use Windows (CRLF) line endings; `.gitattributes` stops Git from converting them.
- No missing observation is filled or interpolated. The validators fail if source data or outputs are missing or inconsistent.
- Yahoo price history shows trading coverage, not eligibility on the case date. Eligibility evidence (dated SEC filings) is in `data/security_eligibility_evidence.csv` and is partial.
- See `data/data_dictionary.md` and `docs/audit/DATA_AUDIT_REPORT.md` for definitions and known limitations.
