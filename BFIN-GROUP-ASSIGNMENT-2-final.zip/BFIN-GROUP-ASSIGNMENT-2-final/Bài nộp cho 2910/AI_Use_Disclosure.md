# AI-Use Disclosure

**Team:** [Group name] · **Submission:** final, 29 October 2026

We used an AI assistant (Notion AI, a large-language-model agent with access to a code sandbox) for material parts of this final submission. This disclosure follows the course's academic-integrity policy. The team is responsible for all content and every member must be able to explain it.

## What the AI assistant did

| Area | AI assistance | What the team did |
|---|---|---|
| Final notebook (Sections 9-12) | Drafted the new code cells for the revised mandate, immunization comparison, loss measures, utility threshold, risk-adjusted evaluation and change attribution, following the style of our 22 October notebook | Specified the methods (from Lectures 3-8), reviewed the code, re-ran it, and checked the results below |
| Reproducibility | Found that the GitHub zip had changed the raw CSV line endings (hash mismatch) and that Windows paths broke the code on Linux; proposed the fixes and `scripts/validate_final.py` | Confirmed the fixes change no number; reviewed the validator |
| Committee memo and slide deck | Drafted text, tables and slide layout from the generated output tables | Edited wording, checked every number against `outputs/final_2026-10-29/`, and checked the interpretation |
| Decision log, data addendum, rebuild guide | Drafted | Reviewed and corrected |
| Contribution statement and critiques | Drafted a template with placeholder critiques | **Each member must replace the placeholder text with their own critique and the actual work split** |

The AI assistant was told to use only methods taught in the course (lecture notebooks 1-11 and the Lecture 8 slides). It did not download new data. All results come from the raw data saved on 20 October 2026.

## Checks we performed

1. Ran `scripts/validate_data.py` (raw-file hashes, processed data rebuilt identically).
2. Executed `Bài nộp cho 2910/analysis_final.ipynb` from a clean kernel and ran `scripts/analysis_final.py` in a fresh copy of the repository; both produce the same `outputs/final_2026-10-29/` files.
3. Ran `scripts/validate_analysis.py --tag final_2026-10-29` and `scripts/validate_final.py`. They check that the 22 October tables T00-T26 are reproduced, that the growth weights and assumptions equal `outputs/original/frozen_policy.json`, that the revised bonds cover every payment, and that the allocation sums to USD 12 million.
4. Hand-checked key numbers: Gamma price from the spot curve, revised bond cost (units × prices), the USD 66,984 cost change, A* = 2.52 from the utility formula, and the 23.7 / 49.9-point decomposition of the gap to SPY.
5. Checked that each table and figure in the memo names its source output.

## Limits of the AI assistance

AI-generated text can sound confident when the evidence is weak. Where the memo makes judgements (for example about A = 4, the 15% measure, or the credibility of the goal), these are the team's judgements and are stated as assumptions. [Team to add any further AI use by individual members, e.g. for the 22 October submission.]
