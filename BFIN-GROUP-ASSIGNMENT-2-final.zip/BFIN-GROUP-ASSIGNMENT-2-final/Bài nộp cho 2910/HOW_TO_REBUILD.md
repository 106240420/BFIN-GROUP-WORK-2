# How to rebuild the final results

All commands run from the **repository root** (the folder that contains `config.json`). No internet connection is needed. Use Python 3.13.

## 1. Install the pinned environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
```

## 2. Check the raw data and rebuild the processed data

```bash
python scripts/validate_data.py
```

This verifies the 13 SHA-256 hashes in `data/raw/source_record.json` and rebuilds `data/processed/`. If a hash check fails after downloading the repository as a ZIP from GitHub, the Yahoo CSV files have lost their Windows (CRLF) line endings. Clone with Git instead (the `.gitattributes` file keeps them unchanged), or use the submitted archive. Never edit the raw files.

## 3. Rebuild every table and figure

Either execute the notebook (Windows: use `\` in the path):

```bash
python -m jupyter nbconvert --to notebook --execute --ExecutePreprocessor.timeout=600 --output-dir build_check "Bài nộp cho 2910/analysis_final.ipynb"
```

or run the equivalent script with a non-interactive plotting backend:

```bash
# macOS / Linux
MPLBACKEND=Agg python scripts/analysis_final.py
# Windows PowerShell
$env:MPLBACKEND = "Agg"; python scripts/analysis_final.py
```

Both write to `outputs/final_2026-10-29/` (tables T00-T37, figures F01-F05, `final_policy_revised.json`). They never write to `outputs/original/`, which is the frozen 22 October baseline. A run takes about one minute.

## 4. Validate

```bash
python scripts/validate_analysis.py --tag final_2026-10-29
python scripts/validate_final.py
```

`validate_final.py` checks that T00-T26 reproduce the 22 October baseline, that the growth weights and assumptions are the frozen ones, that the revised bonds meet every payment, and that the allocation sums to USD 12 million. Both scripts print `All ... checks passed` on success.

## 5. Memo and slides

- `Committee_Memo_2026-10-29.pdf` was produced from `Committee_Memo_2026-10-29.docx`. `document_sources/build_memo.py` rebuilds the DOCX from the output tables (`pip install python-docx`), and LibreOffice or Word exports the PDF.
- `Committee_Presentation_2026-10-29.pptx` is the editable source of `Committee_Presentation_2026-10-29.pdf`.

## Files used by the final analysis

| Purpose | File |
|---|---|
| Raw downloads and source record | `data/raw/`, `data/raw/source_record.json`, `data/source_record.csv` |
| Processed data | `data/processed/` |
| Retrieval code (needs internet; refuses to overwrite the snapshot) | `src/download_data.py` |
| Settings | `config.json` |
| Environment | `requirements-lock.txt` (pinned), `requirements.txt` (direct dependencies) |
| Frozen 22 October policy | `outputs/original/frozen_policy.json`, `Bài nộp cho 2210/` |
