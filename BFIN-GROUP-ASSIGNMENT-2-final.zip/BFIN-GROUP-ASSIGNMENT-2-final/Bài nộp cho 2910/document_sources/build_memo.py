"""Build the committee memo (DOCX) from the generated output tables. Numbers in tables are read from outputs/final_2026-10-29."""
import re, json
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

REPO = Path(__file__).resolve().parents[2]   # repository root (this file sits in "Bài nộp cho 2910/document_sources/")
O = REPO / "outputs" / "final_2026-10-29"
OUT = REPO / "Bài nộp cho 2910"
def T(code, **kw):
    return pd.read_csv(next(O.glob(f"{code}_*.csv")), **kw)

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
sec.left_margin = sec.right_margin = Cm(1.9)
sec.top_margin = Cm(1.6); sec.bottom_margin = Cm(1.5)
FONT = "Arial"
st = doc.styles["Normal"]; st.font.name = FONT; st.font.size = Pt(10)
st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
st.paragraph_format.space_after = Pt(3); st.paragraph_format.line_spacing = 1.08
NAVY = RGBColor(0x1F, 0x3A, 0x5F)

fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = fp.add_run("Kappa Foundation - committee memo, 29 October 2026 - page "); r.font.size = Pt(7.5)
for t, txt in (("begin", None), (None, "PAGE"), ("end", None)):
    run = fp.add_run(); run.font.size = Pt(7.5)
    if t:
        e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), t); run._r.append(e)
    else:
        e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt; run._r.append(e)

def add_runs(p, text, size=None):
    for part in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if not part: continue
        if part.startswith("**"):
            run = p.add_run(part[2:-2]); run.bold = True
        elif part.startswith("`"):
            run = p.add_run(part[1:-1]); run.font.name = "Courier New"; run.font.size = Pt((size or 9.5) - 1)
            continue
        else:
            run = p.add_run(part)
        if size: run.font.size = Pt(size)

def P(text, size=None, after=3, align=None):
    p = doc.add_paragraph(); add_runs(p, text, size); p.paragraph_format.space_after = Pt(after)
    if align: p.alignment = align
    return p

def H(text, lvl=1):
    p = doc.add_paragraph(); r = p.add_run(text); r.bold = True; r.font.color.rgb = NAVY
    r.font.size = Pt(12 if lvl == 1 else 10)
    p.paragraph_format.space_before = Pt(7 if lvl == 1 else 4); p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    return p

def shade(cell, hexcol):
    tcPr = cell._tc.get_or_add_tcPr(); s = OxmlElement("w:shd")
    s.set(qn("w:val"), "clear"); s.set(qn("w:color"), "auto"); s.set(qn("w:fill"), hexcol); tcPr.append(s)

def TBL(caption, rows, widths, source, bold_rows=(), size=8):
    cp = doc.add_paragraph(); r = cp.add_run(caption); r.bold = True; r.font.size = Pt(8.5)
    cp.paragraph_format.space_before = Pt(3); cp.paragraph_format.space_after = Pt(1); cp.paragraph_format.keep_with_next = True
    t = doc.add_table(rows=len(rows), cols=len(rows[0])); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr; lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    grid = t._tbl.tblGrid
    for gc, wd in zip(grid.findall(qn("w:gridCol")), widths): gc.set(qn("w:w"), str(int(wd * 567)))
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            c = t.cell(i, j); c.width = Cm(widths[j]); c.text = ""
            p = c.paragraphs[0]; p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
            run = p.add_run(str(val)); run.font.size = Pt(size)
            if i == 0 or i in bold_rows: run.bold = True
            if j > 0 and size >= 8: p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            if i < len(rows) - 1: p.paragraph_format.keep_with_next = True
            if i == 0: shade(c, "DCE6F0")
            elif i in bold_rows: shade(c, "F2F2F2")
    for j, w in enumerate(widths):
        for cell in t.columns[j].cells: cell.width = Cm(w)
    sp = doc.add_paragraph(); r = sp.add_run("Source: " + source); r.italic = True; r.font.size = Pt(7.5)
    sp.paragraph_format.space_after = Pt(4)

def FIG(path, caption, width=17.0):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(path), width=Cm(width))
    c = doc.add_paragraph(); r = c.add_run(caption); r.italic = True; r.font.size = Pt(7.5)
    c.alignment = WD_ALIGN_PARAGRAPH.CENTER; c.paragraph_format.space_after = Pt(4)

usd = lambda x: f"{x + 0.0:,.0f}".replace("-0", "0") if abs(x) < 0.5 else f"{x:,.0f}"
pct = lambda x, d=1: f"{100*x:.{d}f}%"

p = doc.add_paragraph(); r = p.add_run("Kappa Foundation - Investment Policy Recommendation"); r.bold = True; r.font.size = Pt(15); r.font.color.rgb = NAVY
p.paragraph_format.space_after = Pt(1)
P("**To:** Board of Trustees, Kappa Foundation   **From:** Independent investment team ([Group name]: [Member A], [Member B], [Member C], [Member D])", 8.5, 0)
P("**Date:** 29 October 2026   **Case decision date:** 31 December 2022 (information cutoff)   **Subject:** Final policy under the revised payment schedule of 23 October", 8.5, 5)

H("1. Recommendation")
P("We recommend that the trustees authorise a two-part policy. **First, meet the three fixed payments with case bonds held to maturity**: 2,157 Beta, 1,079 Gamma and 2,243 Delta bonds (USD 5.28m). Their coupons and principal cover USD 2.4m in 2024, USD 1.2m in 2025 and USD 2.4m in 2027 without selling any bond and with surplus cash assumed to earn 0%. **Second, invest USD 6.47m in a diversified, low-beta growth sleeve** of six stocks and two ETFs, at the weights we froze on 22 October, rebalanced each December only if a weight drifts more than 5 percentage points. Keep a USD 243.5k cash buffer. SPY is the policy benchmark for the growth sleeve.")
a = T("T31", index_col=0)
rows = [["Holding", "Units / sleeve weight", "Revised USD", "% of fund", "22 Oct USD"]]
h = T("T28", index_col=0)
for b in ["Beta", "Gamma", "Delta"]:
    rows.append([f"{b} bond", f"{h.loc[b,'units_revised']:,.0f} units", usd(a.loc[b,'usd_revised']), pct(a.loc[b,'pct_of_fund'],2), usd(a.loc[b,'usd_original'])])
bsum = a.loc[["Alpha","Beta","Gamma","Delta"]].sum()
rows.append(["Total bonds", "", usd(bsum.usd_revised), pct(bsum.pct_of_fund,2), usd(bsum.usd_original)])
w = pd.Series(json.loads((O/"final_policy_revised.json").read_text())["growth_weights"])
for k in ["SPY","USMV","PG","JNJ","NEE","UNH","HD","MSFT"]:
    rows.append([k, pct(w[k],2), usd(a.loc[k,'usd_revised']), pct(a.loc[k,'pct_of_fund'],2), usd(a.loc[k,'usd_original'])])
gs = a.loc[["AAPL","MSFT","JPM","JNJ","UNH","XOM","PG","HD","NEE","CAT","SPY","USMV"]].sum()
rows.append(["Growth sleeve (AAPL, JPM, XOM, CAT at 0%)", "100.00%", usd(gs.usd_revised), pct(gs.pct_of_fund,2), usd(gs.usd_original)])
rows.append(["Cash buffer (net) / initial trading cost", "", f"{usd(a.loc['Cash buffer','usd_revised'])} / {usd(a.loc['Trading costs (growth buy)','usd_revised'])}", pct(a.loc['Cash buffer','pct_of_fund']+a.loc['Trading costs (growth buy)','pct_of_fund'],2), f"{usd(a.loc['Cash buffer','usd_original'])} / {usd(a.loc['Trading costs (growth buy)','usd_original'])}"])
rows.append(["Total", "", usd(a.usd_revised.sum()), "100.00%", usd(a.usd_original.sum())])
TBL("Table 1. Recommended initial allocation (revised mandate) and the 22 October allocation", rows, [6.2, 3.0, 2.6, 2.0, 2.6],
    "T31_revised_initial_allocation.csv, T28_revised_bond_holdings.csv, final_policy_revised.json.", bold_rows=(4, 13, 15))
P("**What the foundation can and cannot promise.** The payments are as secure as the case allows: the bonds are default-free, nothing must be sold, cash after each payment is never negative (smallest balance USD 330) and the surplus stays positive in every rate scenario we tested. The 2030 goal cannot be promised. Under our planning assumptions the chance of ending 2030 with the purchasing power of USD 8m is about **69%** (55% if inflation averages 4%). We also cannot promise that losses will stay below 15% on every measure: the growth sleeve's historical peak-to-trough fall was 16.1%, although the total fund's was 8.7%.")

H("2. Response to the revised mandate")
P("The trustees asked us to apply the new schedule at the original decision date with the original quotes. Moving USD 1.2m of the learning-centre payment from 2027 to 2025 changes only the funding block. The 2025 payment falls on Gamma's maturity, so the cheapest whole-unit set of bonds now includes Gamma; Delta falls from 3,258 to 2,243 units. Money is needed earlier, so it is discounted for fewer years and the bonds cost **USD 66,984 more**. The growth sleeve shrinks by the same amount because the USD 250k buffer is unchanged.")
c = T("T30", index_col=0)
def crow(lbl, k, f):
    return [lbl, f(c.loc[k,'original_22oct']), f(c.loc[k,'revised_mandate']), f(c.loc[k,'change'])]
pp = lambda k, d=2: f"{100*c.loc[k,'change']:+.{d}f} pp"
rows = [["Item", "22 Oct (original)", "Revised mandate", "Change"],
        crow("Bond cost (USD)", "bond_cost_usd", usd), crow("Liability PV on bootstrapped curve (USD)", "liability_pv_usd", usd),
        ["Liability / asset Macaulay duration (yrs)", f"{c.loc['liability_macaulay_yrs','original_22oct']:.2f} / {c.loc['asset_macaulay_yrs','original_22oct']:.2f}", f"{c.loc['liability_macaulay_yrs','revised_mandate']:.2f} / {c.loc['asset_macaulay_yrs','revised_mandate']:.2f}", f"{c.loc['liability_macaulay_yrs','change']:+.2f} / {c.loc['asset_macaulay_yrs','change']:+.2f}"],
        crow("Growth sleeve (USD)", "growth_sleeve_usd", usd),
        ["Growth sleeve, % of fund", pct(c.loc['growth_share_of_fund','original_22oct'],2), pct(c.loc['growth_share_of_fund','revised_mandate'],2), pp('growth_share_of_fund')],
        ["Required growth return for 2030 goal (2.5% inflation)", pct(c.loc['required_growth_return_base','original_22oct'],2), pct(c.loc['required_growth_return_base','revised_mandate'],2), pp('required_growth_return_base')],
        ["Expected growth return (CAPM, unchanged weights)", pct(c.loc['expected_growth_return','original_22oct'],2), pct(c.loc['expected_growth_return','revised_mandate'],2), "0.00 pp"],
        ["Probability of reaching the 2030 goal (base / 4% inflation)", f"{pct(c.loc['goal_probability_base','original_22oct'])} / {pct(c.loc['goal_probability_infl_4pct','original_22oct'])}", f"{pct(c.loc['goal_probability_base','revised_mandate'])} / {pct(c.loc['goal_probability_infl_4pct','revised_mandate'])}", f"{100*c.loc['goal_probability_base','change']:+.1f} / {100*c.loc['goal_probability_infl_4pct','change']:+.1f} pp"],
        ["Real 2030 value, P10 / P50 (USD m, 2022 dollars)", f"{c.loc['real_value_P10','original_22oct']/1e6:.2f} / {c.loc['real_value_P50','original_22oct']/1e6:.2f}", f"{c.loc['real_value_P10','revised_mandate']/1e6:.2f} / {c.loc['real_value_P50','revised_mandate']/1e6:.2f}", f"{c.loc['real_value_P10','change']/1e6:+.2f} / {c.loc['real_value_P50','change']/1e6:+.2f}"],
        ["Model 95% one-year loss, total fund", pct(c.loc['model_loss95_total_fund','original_22oct'],2), pct(c.loc['model_loss95_total_fund','revised_mandate'],2), pp('model_loss95_total_fund')],
        ["Inflation at which expected return = required return", pct(c.loc['inflation_threshold','original_22oct'],2), pct(c.loc['inflation_threshold','revised_mandate'],2), pp('inflation_threshold')]]
TBL("Table 2. Consequences of the revised mandate (same decision date, quotes, cutoff and methods)", rows, [7.6, 3.2, 3.2, 2.6], "T30_mandate_comparison.csv; liabilities discounted on the T03 spot curve; probabilities use the lognormal planning model of T23.")
P("**What we retain and what we change.** We retain the dedication method, the growth weights, every assumption (inflation, ERP, risk aversion, cap, costs, buffer), the benchmark, both data windows and the rebalancing rule. Only the bond units and the dollar size of the sleeve change, and `T37_change_attribution.csv` traces each change to the new schedule. We did **not** re-optimise the growth weights: mean-variance weights do not depend on the sleeve's dollar size, and re-optimising now would let 2023-2025 returns, which were unknown at the decision date, enter the decision (hindsight bias, Lecture 8). The only separate changes are reporting diagnostics (Sections 4-7) and a file-path fix that lets the code run on Linux and macOS; neither changes a number in the policy. In retrospect both schedules were met to the end of 2025 without shortfall, and the sleeve would have grown to USD 8.76m (USD 8.85m under the original schedule; `T36`).")

H("3. Mandate interpretation and assumptions")
P("The case leaves the inflation assumption, return target, risk aversion, loss measure and benchmark to us. We fixed them on 22 October and show how each one moves the decision (Table 3). The goal is in real terms: with 2.5% inflation, USD 8m of December-2022 purchasing power is USD 9.75m in December 2030, which needs 4.93% a year on the revised sleeve (`T09`, `T30`).")
rows = [["Assumption", "Base value", "Why we chose it", "What changes if it is wrong"],
        ["Inflation", "2.5% p.a.", "Above the 2% policy target, allowing for the 2022 inflation shock", "Goal probability 75% at 2% and 56% at 4% (T23); expected return falls below required above 5.03% (T30)"],
        ["Equity risk premium", "5% p.a.", "Long-run premium; the 2015-22 sample premium (9.97%, t = 1.71) is too noisy to use (T19)", "Expected return equals the goal requirement at ERP 0.75% (T26); SPY weight falls to 7.7% at ERP 3% (T16)"],
        ["Risk aversion A", "4", "Moderate; trustees dislike losses near 15% but want real growth", "Below A* = 2.52 a 100% SPY sleeve has higher utility (T34)"],
        ["The 15% concern", "Reported, not imposed", "Trustees have not agreed a measure; we report several (Section 5)", "Only the sleeve's maximum drawdown (16.1%) exceeds 15% (T33)"],
        ["Limits", "Long-only, 25% per security", "No borrowing or shorting allowed; cap stops single-name bets", "Caps of 15% / 35% / 100% move USMV to 15% / 35% / 42% (T16)"],
        ["Costs and cash", "10 bp one way; cash 0%", "Conservative: coupons held as cash earn nothing", "Higher carry only adds surplus; buffer USD 250k covers fees and timing"]]
TBL("Table 3. Team-selected assumptions and their consequences", rows, [2.7, 2.6, 5.4, 6.5], "T09, T16, T19, T23, T26, T30, T33, T34.", size=7.5)
P("**Risk-return preference.** We rank portfolios by the certainty-equivalent return U = E(r) - 0.5·A·σ² (Lectures 4-5). A changes the choice a lot. At A = 1 the optimiser holds 17% AAPL, 22% JPM and 25% SPY with 18.8% volatility; at A = 4 it holds the defensive mix in Table 1 with 11.6% volatility; at A = 12 SPY drops out (`T10`). The 95% one-year loss on the total fund falls from 11.6% to 6.2% between A = 1 and A = 4.")

H("4. Bond valuation and funding risk")
b4 = T("T04", index_col=0); b5 = T("T05")
P("The exhibit quotes five bonds but not a full spot curve. The two zeros give the 1- and 2-year spot rates directly (4.30%, 4.10%). Gamma, Delta and Epsilon then give the 3-, 5- and 8-year spots by bootstrapping (3.90%, 3.80%, 3.90%). The 4-, 6- and 7-year spots are not quoted; we interpolate them linearly, which reprices all five bonds exactly (`T03`). The curve is mildly inverted, with implied one-year forwards of 3.5%-4.3%. Durations and convexities come from yield-to-maturity (Lecture 3), and Table 4 checks them against exact repricing.")
rows = [["Bond", "Price", "YTM", "Mod. duration", "Convexity", "+250 bp: duration only", "+ convexity", "Exact repricing"]]
for bb in ["Alpha","Beta","Gamma","Delta","Epsilon"]:
    s = b5[(b5.bond==bb)&(b5.shock_bp==250)].iloc[0]
    rows.append([bb, f"{b4.loc[bb,'price']:,.2f}", pct(b4.loc[bb,'ytm'],3), f"{b4.loc[bb,'modified']:.3f}", f"{b4.loc[bb,'convexity']:.2f}", pct(s.duration_only,2), pct(s.duration_convexity,2), pct(s.exact_spot_curve_reprice,2)])
TBL("Table 4. Bond analytics and accuracy of the duration-convexity approximation", rows, [1.8,1.6,1.6,2.1,1.8,3.2,2.2,2.6], "T03_spot_curve.csv, T04_bond_analytics.csv, T05_duration_vs_exact.csv (±100 bp results in T05).")
P("Duration alone overstates the fall in Epsilon's price at +250 bp by 1.6 points; adding convexity cuts the error to 0.13 points. For the funding decision, the bonds are **held to maturity**, so the payments depend only on contractual cash flows, not on future yields. We choose the cheapest whole-unit set of bonds whose cumulative cash covers every payment (a linear programme), with coupons held at 0% (`T27`, `T28`). Rate scenarios therefore matter only for the mark-to-market surplus. We test parallel shifts of ±100 bp and +250 bp (yields rose by more than 250 bp during 2022, so this is severe but plausible) and a ±50 bp twist between the 1- and 8-year points. Under the revised mandate the surplus stays between **+USD 6.0k and +USD 11.2k** in all six scenarios (`T29`), because asset and liability durations are almost equal (3.30 vs 3.34 years) and the bonds' positive convexity helps in both directions.")
FIG(O/"F03_funding_both_mandates.png", "Figure 1. Bond cash flows against payments, original and revised mandate (F03_funding_both_mandates.png; T06, T27).", 15.0)
P("**Rejected funding alternative: immunization.** A duration-matched portfolio costs exactly the liability PV, USD 7,630 less than dedication. It is not robust to curve shape: a Beta-Epsilon barbell loses USD 29.2k in the steepener and an Alpha-Delta pair loses USD 13.6k, while dedication moves by only ±USD 0.2k (`T32`). Immunization also has to sell Epsilon in 2027 or rebalance as durations drift, which reintroduces the reinvestment and resale risk that dedication removes. We judge certainty for fixed obligations worth the USD 7.6k.")

H("5. Growth portfolio: construction, alternatives and the 15% concern")
P("**Universe and data.** Ten stocks in eight sectors (AAPL, MSFT, JPM, JNJ, UNH, XOM, PG, HD, NEE, CAT) plus SPY (market) and USMV (minimum volatility), with roles and dated SEC evidence in `T02`. We estimate on 96 monthly returns, January 2015 to December 2022, which include the 2020 crash and the 2022 bear market. Returns are built from Yahoo adjusted closes, and factors come from the Kenneth French library; both are saved with hashes (`T00`, `T01`).")
P("**Inputs.** Expected returns are CAPM: E(r) = rf + β × 5% (Lecture 6). We do not use sample means, which are too noisy over eight years. For risk we compare the single-index covariance (Lecture 6) with the sample covariance of the same twelve assets. At A = 4 the single-index weights give 7.59% expected return and 11.57% volatility; the sample-covariance weights give 7.90% and 12.81%; and 15% of the weights differ (`T11`, `T12`, Figure 2). We use the single-index model because it estimates 36 parameters instead of 78, and the sample-covariance weights look riskier even under their own model. The resulting sleeve has a beta of 0.66. SPY contributes 32% of its risk, USMV 25%, JNJ 14% and PG 12% (`T15`).")
P("**Rejected alternative (Eta): maximum historical Sharpe ratio.** This portfolio puts 41% in UNH, 30% in NEE and 28% in MSFT (effective N = 3.0). Using only the last 60 months instead of 96 changes 24% of its weights (`T13`). Under the same CAPM inputs it has about the same expected return as our sleeve (7.61%) but 14.7% volatility, so its utility is lower for any A above 0.05 (`T34`). **Simple comparator: 100% SPY.** It has a higher expected return (9.10%) but adds only 1.6 points of goal probability (71.0% vs 69.4%). Its model loss on the total fund is 9.2% instead of 6.2%, and its sleeve drawdown in 2015-2022 was 23.9% (Table 5).")
FIG(O/"F01_weights.png", "Figure 2. Growth-sleeve weights under single-index and sample-covariance risk estimates, A = 4 (F01_weights.png; T11).", 12.5)
l = T("T33", index_col=0)
lab = {"normal_VaR95_1y":"Normal 95% one-year VaR", "hist_ES95_rolling12m":"Historical 95% ES, rolling 12 months", "worst_12m_loss":"Worst 12-month loss (= calendar 2022)", "max_drawdown":"Maximum drawdown (peak to trough)"}
rows = [["Loss measure, 2015-2022", "Our sleeve", "100% SPY sleeve", "Total fund, our policy", "Total fund, 100% SPY"]]
for k, v in lab.items():
    rows.append([v] + [pct(l.loc[k, cc]) for cc in ["sleeve_recommended","sleeve_if_100pct_SPY","total_fund_revised_recommended","total_fund_revised_if_100pct_SPY"]])
rows.append(["Monthly skewness / excess kurtosis", f"{l.loc['monthly_skewness','sleeve_recommended']:.2f} / {l.loc['monthly_excess_kurtosis','sleeve_recommended']:.2f}", f"{l.loc['monthly_skewness','sleeve_if_100pct_SPY']:.2f} / {l.loc['monthly_excess_kurtosis','sleeve_if_100pct_SPY']:.2f}", "", ""])
TBL("Table 5. The trustees' 15% concern under different measures (losses as positive numbers)", rows, [6.4, 2.4, 2.6, 2.9, 2.9], "T33_loss_measures.csv. Total-fund figures scale sleeve losses by the sleeve's share of the fund; bonds are held to maturity.")
P("Only one measure breaches 15%: the sleeve's maximum drawdown. Staying under 15% on that measure would need about 93% of the sleeve in equities and the rest in cash. Because the trustees' measure is undecided, we report this number rather than build it into the weights. Monthly returns show negative skew, so the normal VaR understates tail risk (Lecture 4); for that reason we also report historical ES and drawdown.")

H("6. What drives return and risk, and which adviser claims survive")
f = T("T18")
g = f[f.asset=="Growth portfolio"].set_index("model")
fmt = lambda v, t: "" if pd.isna(v) else f"{v:.2f} ({t:.1f})"
rows = [["Growth sleeve 2015-22", "Alpha p.a. (t)", "Market", "SMB", "HML", "RMW", "CMA", "Adj. R²"]]
for m in ["CAPM","FF3","FF5"]:
    r_ = g.loc[m]
    rows.append([m, f"{100*r_.alpha_ann:.2f}% ({r_.alpha_t:.2f})"] + [fmt(r_[f'b_{x}'], r_[f't_{x}']) for x in ["Mkt-RF","SMB","HML","RMW","CMA"]] + [f"{r_.adjR2:.2f}"])
o = T("T21").set_index("asset")
rows.append(["FF5 alpha 2023-25 (out of sample)", f"{100*o.loc['Growth portfolio','oos_alpha_ann']:.2f}% ({o.loc['Growth portfolio','t_stat_hac']:.2f})", "", "", "", "", "", ""])
TBL("Table 6. Market-only and multifactor regressions of the growth sleeve (coefficient, t-statistic)", rows, [3.4, 2.5, 2.1, 2.1, 2.1, 1.8, 1.8, 1.4], "T18_factor_regressions.csv (96 months), T21_oos_alpha_check.csv (36 months, HAC t-statistics); security results for AAPL and XOM in T18/T21.")
P("**Drivers.** Market exposure is the main source of return and risk: beta is 0.66-0.72 and the market alone explains 77% of the variance. The multifactor models add a clear style profile: negative SMB (large companies), and positive RMW and CMA (profitable firms with conservative investment), which is a defensive quality tilt. Two securities show why loadings matter. AAPL has a market beta of 1.21 and a CAPM alpha of 12.1% that is not significant (t = 1.73). XOM has beta 1.02 and an FF3 HML loading of 1.04 (value and energy), and its alpha is near zero. **What alpha does not establish:** the sleeve's CAPM alpha of 5.0% (t = 2.71) falls to 2.3% (t = 1.58) once the five factors are included, so most of it was compensation for factor exposures (Lecture 7). Out of sample it was -5.4% (t = -1.25). An estimated alpha is a noisy historical intercept, not a forecast, so our expected returns stay CAPM-based.")
P("**Eta (bonds plus best historical risk-adjusted performance).** The bond half survives, and we use it in a stricter form (dedication). The growth half does not. A past Sharpe ratio estimated over eight years is mostly noise: if markets are even weak-form efficient, past performance alone should not predict abnormal returns (Lecture 8). Choosing on it is representativeness bias, and the result was concentrated and unstable. In 2023-2025 it returned 15.4% with a 21.3% drawdown, the worst of the strategies we froze (`T22`). **Theta (factor exposures and persistent abnormal returns).** Factor exposures survive as a way to explain and monitor risk, and we use them that way. Persistent abnormal returns do not survive: alpha is insignificant after the factors and did not persist after 2022. The factor premia themselves are imprecise in our window (SMB and HML are near zero, and no premium has t > 2; `T19`). Expected returns built on historical premia would be 11.7%-13.5% for the sleeve (`T20`), which we regard as overconfidence in eight years of data.")

H("7. Evidence against our recommendation: 2023-2025")
e = T("T35", index_col=0)
rows = [["Frozen strategy, Jan 2023 - Dec 2025", "Cum. return", "Return p.a.", "Volatility", "Sharpe", "Max DD", "Beta (realised)", "Alpha p.a. (t)"]]
for k, lbl in [("Recommended (frozen)","Recommended sleeve"),("Benchmark SPY","SPY benchmark"),("Beta-matched SPY + T-bill","70% SPY + 30% T-bill (ex-ante beta)"),("Sample-cov MV","Sample-covariance alternative"),("Rejected: Eta max-Sharpe","Eta max-Sharpe (rejected)")]:
    r_ = e.loc[k]; at = "" if pd.isna(r_.alpha_t_hac) else f"{100*r_.alpha_ann_vs_SPY:.1f}% ({r_.alpha_t_hac:.2f})"
    rows.append([lbl, pct(r_.cumulative), pct(r_.ann_return), pct(r_.ann_vol), f"{r_.sharpe:.2f}", pct(r_.max_drawdown), f"{r_.realized_beta_vs_SPY:.2f}", at])
TBL("Table 7. Out-of-sample comparison of the frozen strategies (10 bp costs, December 5 pp rebalancing rule)", rows, [4.7, 1.7, 1.6, 1.7, 1.5, 1.5, 1.8, 2.5], "T22_evaluation_2023_2025.csv, T35_risk_adjusted_evaluation.csv; alpha from the CAPM regression on SPY excess returns, HAC (3 lags).")
P("This result is inconvenient and we report it in full. The sleeve returned 35.4% against SPY's 85.3%. A comparator holding SPY and T-bills at the sleeve's **ex-ante** beta of 0.70 returned 61.6%. Holding less market risk, as intended, therefore explains 23.7 of the 49.9 points; the other 26.2 points come from selection. We held almost no AAPL or MSFT while large technology stocks led the market, and our defensive names lagged. The CAPM alpha of -4.6% a year is not statistically significant (t = -1.29). The sleeve did behave as a lower-risk portfolio, with 10.6% volatility and a -7.2% drawdown against SPY's 11.9% and -8.3%. We do not change the weights because of these 36 months. The rule was frozen in advance, three years cannot show whether the 2030 goal will be met, and switching after seeing the winner would be hindsight bias. Figure 3 shows the paths.")
FIG(O/"F05_evaluation_beta_matched.png", "Figure 3. Value of USD 1, 2023-2025: frozen sleeve, SPY and the beta-matched SPY + T-bill comparator (F05_evaluation_beta_matched.png).", 14.0)

H("8. Credibility of the plan and what would change our mind")
P("**Commitments: high credibility.** They are funded by contractual cash flows from default-free bonds, the cash buffer is separate, and no scenario produces a shortfall. **2030 goal: moderate credibility.** The sleeve needs 4.93% a year and is expected to earn 7.59%, but the goal probability is 69%. The 10th-percentile outcome is USD 6.37m in 2022 dollars, and the real value we can reach with 75% confidence is USD 7.62m (`T30`). **Feasible alternative for the trustees:** keep the policy and restate the goal as \"USD 8m real with about 70% probability\", or as \"USD 7.6m real with 75% confidence\". Raising equity risk barely helps: 100% SPY adds 1.6 points of probability for a 24% sleeve drawdown.")
rows = [["What would change our recommendation", "Threshold", "Action"],
        ["Trustees' risk aversion is lower than assumed", "A < 2.52 (A < 3.00 with sample covariance)", "Replace the sleeve with 100% SPY (T34, Figure 4)"],
        ["Equity premium expectations collapse", "ERP < 0.75%", "Expected return falls below the goal requirement; revisit the goal (T26)"],
        ["Persistent high inflation", "Inflation > 5.03% p.a.", "Same; consider restating the real goal (T30)"],
        ["Trustees adopt a hard 15% sleeve-drawdown limit", "Equity share > 93% of sleeve", "Hold about 7% of the sleeve in cash (T33)"],
        ["Selection keeps losing to the beta-matched comparator", "Alpha t < -2 over at least five years, or realised beta outside 0.5-0.9", "Review the stock selection; consider SPY + USMV only"],
        ["A holding was not eligible at the case date", "Evidence fails for any security", "Remove it and re-optimise on 2015-22 data only"]]
TBL("Table 8. Reversal thresholds", rows, [6.4, 5.2, 5.6], "T26, T30, T33, T34, T35.", size=7.5)
FIG(O/"F04_utility_vs_risk_aversion.png", "Figure 4. Certainty-equivalent return by risk aversion; the dotted line marks A* = 2.52, where 100% SPY overtakes our sleeve (F04_utility_vs_risk_aversion.png; T34).", 12.0)

H("9. Monitoring, governance and limitations")
P("**Each December** the committee should: (1) confirm that bond cash covers the next payment and that the buffer is intact; (2) apply the 5 pp rebalancing rule using only information available on that date; (3) report the sleeve's and the total fund's 12-month loss and drawdown against 15%; (4) compare the real value of the sleeve with the path required for the goal at 4.93% a year; (5) track inflation against the 5% threshold; (6) re-estimate beta and alpha against SPY and against the beta-matched comparator. Any change must be logged and compared with the frozen 22 October policy, not written over it.")
P("**Limitations.** (i) This is a retrospective case. We chose well-known companies that still exist in 2026, so the universe has survivorship and selection bias, and our eligibility evidence (2022 SEC filings) is dated but partial. (ii) Yahoo adjusted prices and French factors are revised after the fact. Our snapshot was retrieved on 20 October 2026 and is hash-checked. Later data may differ. (iii) The bonds are fictional, so there is no price history; the 4-, 6- and 7-year spots are interpolated, and cash carry is assumed to be 0%. (iv) Goal probabilities use a lognormal model with CAPM returns and 96 months of risk estimates. Negative skew and parameter error make them approximate. (v) Options such as protective puts could cap losses (Lecture 10), but the mandate forbids derivatives. The full analysis is in `analysis_final.ipynb`, which rebuilds every table offline from the saved raw data.")

H("10. Decisions requested from the trustees")
P("(1) Authorise the allocation in Table 1 and the December rebalancing rule. (2) Confirm how the 15% concern should be measured; if it is a hard limit on sleeve drawdown, we would hold about 7% of the sleeve in cash. (3) Confirm whether the 2030 goal is \"USD 8m real with about 70% probability\" or a lower real target with higher confidence. (4) Approve the annual monitoring report in Section 9 and the reversal thresholds in Table 8 as triggers for a formal review, not for automatic trading.")
p = doc.add_paragraph(); p.add_run().add_break(WD_BREAK.PAGE)
H("References and output trace")
refs = [
 "BFIN WS2026 Investments, Lecture notebooks 01-07 and 09-11 (bond prices and yields; duration, convexity and immunization; return, risk, VaR and expected shortfall; capital allocation and Markowitz optimisation; single-index model and CAPM; multifactor models and APT; options).",
 "Dam, A. (2026). The Efficient Market Hypothesis & Behavioral Finance, BFIN WS2026 Lecture 8 slides.",
 "BFIN WS2026 Group Assignment: Kappa Foundation, case brief and Revised Mandate (23 October 2026).",
 "Yahoo Finance daily prices with dividends and splits via yfinance 1.7.0 (auto_adjust=False, 1 Dec 2014 - 31 Dec 2025), retrieved 20 Oct 2026 10:51 UTC; identifiers, settings and SHA-256 hashes in data/raw/source_record.json.",
 "Kenneth R. French Data Library, Fama/French 5 Factors (2x3), monthly, F-F_Research_Data_5_Factors_2x3_CSV.zip, retrieved 20 Oct 2026 (URL and hash in data/raw/source_record.json).",
 "U.S. Securities and Exchange Commission EDGAR filings (2021-2022 Forms 10-K/10-Q and ETF prospectuses) for the twelve candidates, listed with dates and URLs in data/security_eligibility_evidence.csv.",
 "Team submission of 22 October 2026: Initial Decision Record, Dated Data Record and analysis.ipynb (folder 'Bài nộp cho 2210'), frozen outputs in outputs/original/.",
]
for i, rr in enumerate(refs, 1):
    P(f"[{i}] {rr}", 8.5, 2)
rows = [["Memo item", "Generated output (outputs/final_2026-10-29/)"],
        ["Table 1", "T31_revised_initial_allocation.csv, T28_revised_bond_holdings.csv, final_policy_revised.json"],
        ["Table 2, Section 2", "T30_mandate_comparison.csv, T37_change_attribution.csv, T36_retrospective_sleeve_value_2025.csv"],
        ["Table 3", "T09, T16, T19, T23, T26, T30, T33, T34"],
        ["Table 4, Section 4", "T03_spot_curve.csv, T04_bond_analytics.csv, T05_duration_vs_exact.csv, T27, T29, T32"],
        ["Figure 1", "F03_funding_both_mandates.png (data T06, T27)"],
        ["Section 5, Figure 2, Table 5", "T02, T11, T12, T13, T15, T34, T33_loss_measures.csv; F01_weights.png"],
        ["Table 6, Section 6", "T18_factor_regressions.csv, T19, T20, T21_oos_alpha_check.csv, T22"],
        ["Table 7, Figure 3", "T22_evaluation_2023_2025.csv, T35_risk_adjusted_evaluation.csv, F05_evaluation_beta_matched.png"],
        ["Table 8, Figure 4", "T26, T30, T33, T34, F04_utility_vs_risk_aversion.png"]]
TBL("Output trace (all files are produced by Bài nộp cho 2910/analysis_final.ipynb or scripts/analysis_final.py)", rows, [4.0, 13.2], "the original 22 October tables T00-T26 are reproduced unchanged and checked by scripts/validate_final.py.", size=7.5)
doc.save(OUT/"Committee_Memo_2026-10-29.docx")
print("saved")
