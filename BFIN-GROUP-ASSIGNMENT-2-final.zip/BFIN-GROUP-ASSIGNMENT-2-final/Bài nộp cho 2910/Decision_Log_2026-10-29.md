# Decision Log — final submission, 29 October 2026

This log continues the [22 October log](../docs/decisions/Decision_Log_2026-10-22.md). The 22 October entries are not edited. The original policy and its outputs stay frozen in `outputs/original/` (and `Bài nộp cho 2210/`). Every final number is in `outputs/final_2026-10-29/`.

## Consequential changes

| Date | Change | Cause | Evidence | Effect on the policy |
|---|---|---|---|---|
| 23 Oct 2026 | Payments become USD 2.4m (2024), USD 1.2m (2025), USD 2.4m (2027), assessed at 31 Dec 2022 with the original quotes. | Revised mandate from the trustees | Mandate update PDF | New funding problem; everything else unchanged |
| 24 Oct 2026 | Bond holdings change from Beta 2,172 + Delta 3,258 to **Beta 2,157 + Gamma 1,079 + Delta 2,243**. Bond cost rises by USD 66,983.96 to USD 5,283,878.18. | Revised mandate | `T27`, `T28`, `T30`; same LP dedication method as `T06/T07` | Gamma is used because the new 2025 payment falls on its maturity. Cash after payments: USD 330 / 995 / 1,005 |
| 24 Oct 2026 | Growth sleeve falls to USD 6,466,121.82 (53.88% of fund). Buffer stays USD 250k. | Revised mandate | `T31` | Dollar amounts per holding fall by about 1.0%; weights unchanged |
| 24 Oct 2026 | Goal probability 70.6% → 69.4%; required growth return 4.80% → 4.93%; model total-fund 95% loss 6.23% → 6.17%; inflation threshold 5.17% → 5.03%. | Revised mandate | `T30` | Reported to the trustees; no change to weights |
| 25 Oct 2026 | Added diagnostics: immunization vs dedication (`T32`), several loss measures (`T33`), utility comparison and risk-aversion threshold A* (`T34`, `F04`), CAPM alpha and beta-matched comparator for 2023-2025 (`T35`, `F05`), retrospective sleeve value (`T36`), change attribution (`T37`). | Method addition, reporting only | Section 11-12 of `analysis_final.ipynb` | None. `validate_final.py` checks that weights and assumptions equal the frozen ones |
| 25 Oct 2026 | Raw-file path handling made portable (`\` in `source_record.json` → `/` when reading) in the notebook, `scripts/analysis.py` and `scripts/validate_data.py`. | Reproducibility fix | Notebook failed on Linux/macOS before the fix | None. Hashes and processed data identical |
| 25 Oct 2026 | Restored Windows (CRLF) line endings of the 12 Yahoo CSVs after downloading the repository as a GitHub zip, and added `.gitattributes` (`data/raw/** -text`). | Data integrity | The GitHub zip had converted CRLF → LF, so SHA-256 hashes no longer matched `source_record.json`. After restoring CRLF all 13 hashes match | None. File contents are unchanged apart from line endings; no data were re-downloaded or edited |
| 26 Oct 2026 | `T35`: alpha t-statistic left blank for SPY and the beta-matched comparator (they fit SPY exactly, so the t-statistic is meaningless). | Reporting fix | `T35_risk_adjusted_evaluation.csv` | None |

## Choices we considered and rejected

| Alternative | Why we rejected it | Evidence |
|---|---|---|
| Re-optimise the growth weights for the revised mandate | Mean-variance weights do not depend on the sleeve's dollar size. Re-running the optimiser after seeing 2023-2025 would bring hindsight into a 31 Dec 2022 decision. | `T37`; Lecture 8 (hindsight bias) |
| Change the sleeve after the weak 2023-2025 result | 36 months; CAPM alpha −4.6% p.a. with t = −1.29 is not significant; about half the gap to SPY is the lower beta we chose deliberately. | `T22`, `T35`, `F05` |
| 100% SPY growth sleeve | Higher utility only if A < 2.52. Goal probability gain is small (71.0% vs 69.4%) for a larger loss (total-fund model loss 9.2% vs 6.2%; sleeve drawdown 23.9% vs 16.1%). | `T33`, `T34` |
| Immunization instead of dedication | USD 7,630 cheaper, but loses up to USD 29.2k in a curve steepener and needs resale of Epsilon in 2027 and rebalancing. | `T32` |
| Eta's maximum historical Sharpe portfolio | Concentrated (effective N = 3.0) and unstable (24% of weights change with a 60-month window); worst 2023-2025 result. | `T13`, `T22`, `T34` |
| Theta's alpha-based expected returns | Alpha falls from 5.02% (CAPM) to 2.34% (FF5, t = 1.58) and was −5.37% out of sample. Factor premia are imprecise in the window. | `T18`, `T19`, `T20`, `T21` |
| Imposing a hard 15% drawdown limit on the sleeve | Trustees have not agreed the measure. We report what it would need (about 93% equity in the sleeve) instead. | `T33` |
| Changing inflation, ERP, A, cap or cost assumptions | Kept fixed so the mandate effect is isolated; thresholds are reported instead. | `T26`, `T30`, `T34`, `T37` |

## Still open for the team

- Confirm the member names, contributions and critiques in `Contribution_Statement_and_Critiques.md`.
- Eligibility evidence remains partial (dated 2021-2022 SEC filings, not a case-date listing record).
- The trustees still have to choose the 15% loss measure and the confidence level for the 2030 goal.
