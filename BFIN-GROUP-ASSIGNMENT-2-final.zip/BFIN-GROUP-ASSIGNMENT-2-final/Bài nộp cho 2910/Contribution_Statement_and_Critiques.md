# Contribution Statement and Member Critiques

**Team:** [Group name] · **Submission:** final, 29 October 2026

> **To complete before submitting:** replace every `[Member X]` with a real name, adjust the work split so it matches what each person actually did, and have each member rewrite their critique in their own words. Every member must be able to explain the analysis submitted under their name.

## Who did what, and who checked it

| Work item | Main author | Checked by | What the check covered |
|---|---|---|---|
| Data retrieval (`src/download_data.py`), source record, hashes, data dictionary | [Member A] | [Member B] | Re-ran `scripts/validate_data.py`; confirmed 13 hashes and the CRLF restoration |
| Bond valuation, spot curve, duration/convexity, dedication LP, rate scenarios (T03-T08, T27-T29) | [Member B] | [Member C] | Repriced Gamma and Delta by hand from `T03`; checked that cash never goes negative in `T27` |
| Immunization comparison (T32) | [Member B] | [Member D] | Checked duration match and the steepener/flattener signs |
| Universe, eligibility evidence, CAPM inputs, single-index vs sample covariance, weights (T02, T10-T17) | [Member C] | [Member A] | Re-computed sleeve beta and expected return from `T15`; checked the 25% cap and long-only constraint |
| Factor regressions and out-of-sample alpha (T18-T21) | [Member D] | [Member C] | Matched the regression window (96 months) and HAC settings; checked factor units |
| 2023-2025 evaluation, beta-matched comparator, loss measures, utility threshold (T22-T26, T33-T35) | [Member D] | [Member B] | Checked rebalancing dates and costs; recomputed A* = 2.52 from `T34` |
| Revised-mandate comparison and change attribution (T30, T31, T36, T37) | [Member A] | [Member D] | Checked that T31 sums to USD 12m and that weights equal `outputs/original/frozen_policy.json` |
| Committee memo | [Member C] (lead), all | [Member A] | Every number traced to a named output; page limit |
| Slide deck | [Member D] (lead), all | [Member B] | Numbers match the memo and tables |
| Decision log, rebuild instructions, AI-use disclosure | [Member A] | [Member C] | Clean rebuild from raw data following `HOW_TO_REBUILD.md` |

## Each member's critique of the final recommendation

**[Member A].** The bond block is robust, but our case for the growth sleeve depends on an assumed risk aversion of 4 that the trustees never gave us. The threshold A* = 2.52 is not far below 4. A short trustee questionnaire about acceptable losses would make the choice of A much easier to defend than our own judgement.

**[Member B].** Dedication costs only USD 7.6k more than immunization and removes curve risk, so I agree with it. My concern is the 0% cash-carry assumption and the interpolated 4-, 6- and 7-year spots. They are conservative for funding, but they also mean our surplus numbers are model-dependent. In practice we would want real Treasury strips to check the curve.

**[Member C].** Our universe is ten large, well-known companies that we picked in 2026. That is survivorship and selection bias, and our eligibility evidence is partial. The sleeve is also very defensive (JNJ, PG, NEE). The 2023-2025 underperformance is not significant, but I am not fully convinced that holding almost no technology stocks is a deliberate risk decision rather than an artefact of the CAPM inputs with a 25% cap.

**[Member D].** I would have reported the goal more cautiously. A 69% probability comes from a lognormal model with CAPM returns and 96 months of risk data, while the monthly returns show negative skew. The P10 real value of USD 6.37m is probably the more honest number for the trustees. I support not changing the weights after 2023-2025, but we should agree in advance what evidence would make us move to SPY + USMV only.
