# Dated Data Record — addendum for the final submission (29 October 2026)

The [22 October data record](../Bài%20nộp%20cho%202210/Dated_Data_Record_2026-10-22.md) still applies. No data were downloaded after 20 October 2026, and the information cutoff for every decision is 31 December 2022.

| Item | Status on 29 October 2026 |
|---|---|
| Raw files | `data/raw/yahoo/*.csv` (12 tickers) and `data/raw/french/F-F_Research_Data_5_Factors_2x3_CSV.zip`, retrieved 20 Oct 2026 10:51 UTC with yfinance 1.7.0, pandas 3.0.6, Python 3.13.15 |
| Hashes | All 13 SHA-256 hashes match `data/raw/source_record.json` (checked by `scripts/validate_data.py` and by the notebook's integrity cell `T00`) |
| Line endings | The Yahoo CSVs were saved on Windows with CRLF line endings. A GitHub "Download ZIP" converts them to LF, which changes the hash. We restored CRLF (content unchanged) and added `.gitattributes` so Git no longer converts them. Do not open and re-save these files in an editor |
| Processed data | `data/processed/` rebuilt by `scripts/validate_data.py`; identical to the 22 October version |
| Revised mandate | Uses no new data. Same bond quotes (case Exhibit 1), same 2015-2022 estimation window, same 2023-2025 evaluation window |
| New outputs | `outputs/final_2026-10-29/` (T00-T37, F01-F05, `frozen_policy.json`, `final_policy_revised.json`). `outputs/original/` is unchanged |
| Known data limits | Yahoo adjusted prices and French factors are revised over time, so a new download may differ slightly; the universe was chosen in 2026 (survivorship and selection bias); eligibility evidence is dated but partial |
